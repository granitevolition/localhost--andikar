"""
MongoDB Local Server Setup Script

This script helps you set up a local MongoDB server for development.
It provides instructions for installing and running MongoDB locally.

Usage:
1. Run this script: python setup_local_mongodb.py
2. Follow the instructions provided
"""

import os
import sys
import subprocess
import platform

def check_mongo_installed():
    """Check if MongoDB is installed"""
    try:
        # Try to run mongo --version to check if MongoDB is installed
        result = subprocess.run(['mongod', '--version'], 
                               stdout=subprocess.PIPE, 
                               stderr=subprocess.PIPE, 
                               text=True)
        if result.returncode == 0:
            version_line = result.stdout.split('\n')[0]
            print(f"✅ MongoDB is installed: {version_line}")
            return True
        return False
    except FileNotFoundError:
        return False

def print_installation_instructions():
    """Print instructions for installing MongoDB based on the OS"""
    system = platform.system()
    
    print("\n=== MongoDB Installation Instructions ===\n")
    
    if system == "Windows":
        print("To install MongoDB on Windows:")
        print("1. Download the MongoDB Community Server from:")
        print("   https://www.mongodb.com/try/download/community")
        print("2. Run the installer and follow the installation wizard")
        print("3. Add MongoDB bin directory to your PATH")
        print("   Typically: C:\\Program Files\\MongoDB\\Server\\<version>\\bin")
        print("4. Create a data directory (e.g., C:\\data\\db)")
        print("5. Run MongoDB as a service or using mongod command\n")
    
    elif system == "Darwin":  # macOS
        print("To install MongoDB on macOS using Homebrew:")
        print("1. Install Homebrew if not already installed:")
        print("   /bin/bash -c \"$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)\"")
        print("2. Install MongoDB Community Edition:")
        print("   brew tap mongodb/brew")
        print("   brew install mongodb-community")
        print("3. Start MongoDB:")
        print("   brew services start mongodb-community\n")
    
    elif system == "Linux":
        print("To install MongoDB on Linux (Ubuntu example):")
        print("1. Import MongoDB public GPG key:")
        print("   wget -qO - https://www.mongodb.org/static/pgp/server-6.0.asc | sudo apt-key add -")
        print("2. Create a list file for MongoDB:")
        print("   echo \"deb [ arch=amd64,arm64 ] https://repo.mongodb.org/apt/ubuntu $(lsb_release -cs)/mongodb-org/6.0 multiverse\" | sudo tee /etc/apt/sources.list.d/mongodb-org-6.0.list")
        print("3. Update package database:")
        print("   sudo apt-get update")
        print("4. Install MongoDB packages:")
        print("   sudo apt-get install -y mongodb-org")
        print("5. Start MongoDB:")
        print("   sudo systemctl start mongod\n")
    
    print("For detailed instructions, visit: https://docs.mongodb.com/manual/installation/\n")

def setup_local_data_directory():
    """Setup a local data directory for MongoDB if on Windows"""
    system = platform.system()
    if system == "Windows":
        data_dir = "C:\\data\\db"
        if not os.path.exists(data_dir):
            try:
                os.makedirs(data_dir, exist_ok=True)
                print(f"✅ Created MongoDB data directory: {data_dir}")
            except Exception as e:
                print(f"❌ Failed to create data directory: {str(e)}")
                print("   Please manually create the directory C:\\data\\db")
        else:
            print(f"✅ MongoDB data directory already exists: {data_dir}")

def print_local_mongodb_instructions():
    """Print instructions for starting and using local MongoDB"""
    system = platform.system()
    
    print("\n=== Running MongoDB Locally ===\n")
    
    if system == "Windows":
        print("To start MongoDB manually on Windows:")
        print("1. Open Command Prompt as Administrator")
        print("2. Run: mongod")
        print("   (This will start MongoDB using the default data directory C:\\data\\db)")
        print("3. Keep this window open while working with MongoDB")
        print("\nAlternatively, you can install MongoDB as a Windows service:")
        print("   mongod --install --serviceName \"MongoDB\"")
    
    elif system == "Darwin":  # macOS
        print("To start MongoDB on macOS:")
        print("1. Run: brew services start mongodb-community")
        print("2. To stop: brew services stop mongodb-community")
    
    elif system == "Linux":
        print("To start MongoDB on Linux:")
        print("1. Run: sudo systemctl start mongod")
        print("2. To stop: sudo systemctl stop mongod")
    
    print("\nTo verify MongoDB is running, open another terminal/command prompt and run:")
    print("   mongosh")
    print("You should see the MongoDB shell connect to localhost:27017\n")

def print_app_configuration():
    """Print instructions for configuring the app to use local MongoDB"""
    print("\n=== Configuring Your App ===\n")
    print("Your application has been configured to use the local MongoDB server.")
    print("MongoDB connection URI: mongodb://localhost:27017")
    print("Database name: andikar_db\n")
    
    print("If you need to modify the connection settings, edit:")
    print("C:\\Users\\uSER\\Desktop\\claude code\\config.py\n")
    
    print("To manually create the 'andikar_db' database and necessary collections:")
    print("1. Start MongoDB")
    print("2. Open MongoDB shell with: mongosh")
    print("3. Run these commands:")
    print("   use andikar_db")
    print("   db.createCollection('users')")
    print("   db.createCollection('payments')")
    print("   db.createCollection('transactions')")
    print("   db.createCollection('transaction_logs')\n")

def main():
    """Main function to run the script"""
    print("\n===== MongoDB Local Setup Helper =====\n")
    
    # Check if MongoDB is installed
    mongo_installed = check_mongo_installed()
    
    if not mongo_installed:
        print("❌ MongoDB is not installed or not in your PATH")
        print_installation_instructions()
    
    # Setup data directory if needed
    setup_local_data_directory()
    
    # Print instructions for running MongoDB locally
    print_local_mongodb_instructions()
    
    # Print app configuration instructions
    print_app_configuration()
    
    print("\n===== Setup Complete =====\n")
    print("After following these instructions, your application should be able to")
    print("connect to the local MongoDB server without any connection issues.")

if __name__ == "__main__":
    main()
