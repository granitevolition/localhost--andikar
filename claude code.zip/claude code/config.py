import os

# App name
APP_NAME = "Andikar AI"

# In-memory fallback flag - set to True when MongoDB is unavailable
USING_IN_MEMORY = False

# Pricing plans (modified to match the payment system)
SUBSCRIPTION_PLANS = {
    "free": {
        "price": 0,  # KES
        "words": "800",
        "words_count": 800,
        "daily_limit": 800,
        "per_request_limit": "300",
        "per_request_limit_count": 300,
        "description": "Perfect for casual users to try our service",
        "name": "Free Plan",
        "ip_limit": 1  # Only one IP address allowed
    },
    "basic": {
        "price": 15,  # KES (set low for testing)
        "words": "20,000",
        "words_count": 20000,
        "per_request_limit": "1,000",
        "per_request_limit_count": 1000,
        "description": "Ideal for individuals with moderate usage needs",
        "name": "Basic Plan",
        "ip_limit": 3  # 3 IP addresses allowed
    },
    "premium": {
        "price": 25,  # KES (set low for testing)
        "words": "40,000",
        "words_count": 40000,
        "per_request_limit": "2,000",
        "per_request_limit_count": 2000,
        "description": "Best value for professionals and small teams",
        "name": "Premium Plan",
        "ip_limit": 8  # 8 IP addresses allowed
    },
    "enterprise": {
        "price": 50,  # KES (set low for testing)
        "words": "100,000",
        "words_count": 100000,
        "per_request_limit": "5,000",
        "per_request_limit_count": 5000,
        "description": "Comprehensive solution for businesses with high-volume needs",
        "name": "Enterprise Plan",
        "ip_limit": 10  # 10 IP addresses allowed
    }
}

# Guest user limits
GUEST_LIMITS = {
    "total_words": 600,  # Total words for guest users
    "max_per_request": 300  # Maximum words per request
}

# Configuration class
class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY', 'development-key-change-in-production')
    DEBUG = os.environ.get('FLASK_DEBUG', 'False').lower() in ['true', '1', 't']
    # Use remote MongoDB with fallback options
    MONGO_URI = os.environ.get('MONGO_URI', 'mongodb+srv://edgarmaina003:Andikar_25@oldtrafford.id96k.mongodb.net/?retryWrites=true&w=majority&appName=OldTrafford')
    API_KEY = os.environ.get('API_KEY', '7c8a3202ae14857e71e3a9db78cf62139772cae6')  # Default API key
    API_BASE_URL = os.environ.get('API_BASE_URL', 'https://lipia-api.kreativelabske.com/api')
    CALLBACK_URL = os.environ.get('CALLBACK_URL')  # Will be set based on the deployment URL
    
    # MongoDB settings
    MONGO_DB_NAME = os.environ.get('MONGO_DB_NAME', 'andikar_db')
    MONGO_MAX_POOL_SIZE = 50
    MONGO_MIN_POOL_SIZE = 10
    MONGO_MAX_IDLE_TIME_MS = 10000  # 10 seconds
    MONGO_CONNECT_TIMEOUT_MS = 30000  # 30 seconds
    MONGO_SERVER_SELECTION_TIMEOUT_MS = 30000  # 30 seconds
    MONGO_SOCKET_TIMEOUT_MS = 45000  # 45 seconds
    
    # Payment settings
    PAYMENT_TIMEOUT_SECONDS = 120  # 120 seconds timeout for payments (increased from 60)
    BASIC_SUBSCRIPTION_WORDS = SUBSCRIPTION_PLANS["basic"]["words_count"]
    PREMIUM_SUBSCRIPTION_WORDS = SUBSCRIPTION_PLANS["premium"]["words_count"]
    BASIC_SUBSCRIPTION_AMOUNT = SUBSCRIPTION_PLANS["basic"]["price"]
    PREMIUM_SUBSCRIPTION_AMOUNT = SUBSCRIPTION_PLANS["premium"]["price"]
    CURRENCY = 'KSH'
    PHONE_FORMAT = '07'  # Always use 07XXXXXXXX format for payments