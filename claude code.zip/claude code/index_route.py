# Updated index route to show the enhanced landing page with both humanizer options

@app.route('/')
def index():
    """Show enhanced landing page with both humanizer options."""
    # Check if we're using in-memory fallback and show a warning flash message
    if hasattr(config, 'USING_IN_MEMORY') and config.USING_IN_MEMORY:
        flash("Database connection is currently unavailable. Using limited functionality mode.", "warning")
    
    # Check if user is a guest
    is_guest = 'user_id' not in session
    
    return render_template('index_enhanced.html', is_guest=is_guest)
