/**
 * Andikar AI - Humanize Text Functionality
 */

document.addEventListener('DOMContentLoaded', function() {
    // Initialize the humanize form elements
    const humanizeForm = document.getElementById('humanize-form');
    const humanizeBtn = document.getElementById('humanize-btn');
    
    if (humanizeForm && humanizeBtn) {
        // Properly handle form submission
        humanizeBtn.addEventListener('click', function(event) {
            event.preventDefault();
            
            // Get the form data from the rich text editor
            const originalEditor = document.querySelector('#original-editor .ql-editor');
            if (originalEditor) {
                document.getElementById('original_text').value = originalEditor.innerHTML;
                document.getElementById('html_content').value = originalEditor.innerHTML;
            }
            
            // Collect format preservation settings if they exist
            if (document.getElementById('format_preserved_elements')) {
                collectPreservationSettings();
            }
            
            // Show processing indicator
            humanizeBtn.disabled = true;
            const processingIndicator = document.getElementById('processing-indicator');
            if (processingIndicator) {
                processingIndicator.style.display = 'block';
                const processingProgress = document.getElementById('processing-progress');
                if (processingProgress) {
                    processingProgress.style.width = '0%';
                
                    // Simulate progress for visual feedback
                    let progress = 0;
                    const progressInterval = setInterval(function() {
                        progress += 1;
                        if (progress > 95) {
                            clearInterval(progressInterval);
                        }
                        processingProgress.style.width = progress + '%';
                    }, 600);
                }
            }
            
            // Submit the form
            humanizeForm.submit();
        });
    }
    
    // Function to collect format preservation settings
    function collectPreservationSettings() {
        // Only proceed if elements exist
        if (!document.getElementById('preserve_quotes')) return;
        
        const settings = {
            preserve_quotes: document.getElementById('preserve_quotes').checked,
            preserve_bold: document.getElementById('preserve_bold').checked,
            preserve_headings: document.getElementById('preserve_headings').checked,
            preserve_links: document.getElementById('preserve_links').checked,
            preserve_images: document.getElementById('preserve_images').checked,
            preserve_lists: document.getElementById('preserve_lists').checked,
            custom_elements: document.getElementById('custom-elements').value,
            preservation_level: document.getElementById('preservation-level').value,
            humanization_strength: document.getElementById('humanization-strength').value
        };
        
        // Store in hidden field
        document.getElementById('format_preserved_elements').value = JSON.stringify(settings);
    }
});
