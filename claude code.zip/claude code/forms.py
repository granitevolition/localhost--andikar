"""
Fallback forms module to ensure the application works
even if the backend.payments.forms module is not available
"""

from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField, EmailField
from wtforms.validators import DataRequired, Email, EqualTo, Length, ValidationError

class RegistrationForm(FlaskForm):
    """Registration form with phone number field for payments"""
    username = StringField('Username', validators=[
        DataRequired(),
        Length(min=3, max=20)
    ])
    
    password = PasswordField('Password', validators=[
        DataRequired(),
        Length(min=4, max=20)
    ])
    
    confirm_password = PasswordField('Confirm Password', validators=[
        DataRequired(),
        EqualTo('password', message='Passwords must match')
    ])
    
    email = StringField('Email', validators=[
        Length(min=0, max=100)
    ])
    
    phone_number = StringField('Phone Number (for payments)', validators=[
        DataRequired()
    ])
    
    submit = SubmitField('Register')

class LoginForm(FlaskForm):
    """Login form"""
    username = StringField('Username', validators=[
        DataRequired(),
        Length(min=3, max=20)
    ])
    
    password = PasswordField('Password', validators=[
        DataRequired()
    ])
    
    submit = SubmitField('Login')

class UseWordsForm(FlaskForm):
    """Form for using words from balance"""
    words_to_use = StringField('Words to Use', validators=[
        DataRequired()
    ])
    
    submit = SubmitField('Use Words')