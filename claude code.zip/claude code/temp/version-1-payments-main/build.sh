#!/bin/bash
# Simple build script for Railway deployment

echo "Installing dependencies..."
cd backend
npm install

echo "Setup complete!"
