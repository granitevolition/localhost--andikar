#!/bin/bash
echo "Starting minimalist server..."
node base-server.js
