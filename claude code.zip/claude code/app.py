
import os
import logging
import time
from datetime import datetime
import json
import random
import pymongo
from bson.objectid import ObjectId

# Import backend modules - be explicit about what we're importing
from backend.api_service import humanize_text, get_api_status, HumanizerAPIError, count_words
from backend.db import init_db, add_user, verify_user, get_user, update_user_usage, add_user_ip, users_collection
from flask import Flask, render_template, request, redirect, url_for, flash, session, jsonify

# Import payment processor
from backend.payments import start_payment_processor, stop_payment_processor, process_payment_callback, get_transaction_status, initiate_payment_async

# Import support bot module
from support_bot import register_support_bot

# Import configuration
import config
from config import Config, SUBSCRIPTION_PLANS, GUEST_LIMITS

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize Flask app
app = Flask(__name__)
app.secret_key = Config.SECRET_KEY

# Check user limit function needed by humanize route
def check_user_limit(username, limit_type):
    """Always return success for any limit check."""
    return True, "No limits applied"

# Make Config available to all templates
@app.context_processor
def inject_config():
    return dict(Config=Config)

# Initialize MongoDB client
mongo_client = None
mongo_db = None

try:
    # Create MongoDB client with explicit timeout and options
    mongo_uri = Config.MONGO_URI
    logger.info(f"Connecting to MongoDB: {mongo_uri}")
    logger.info(f"Database name: {Config.MONGO_DB_NAME}")
    
    # Try to resolve the host first to check DNS
    hostname = mongo_uri.split('@')[-1].split('/')[0]
    if '?' in hostname:
        hostname = hostname.split('?')[0]
    if ':' in hostname:
        hostname = hostname.split(':')[0]
    
    # Don't let DNS resolution issues block our connection attempt
    # We'll bypass DNS checks since we know it worked before despite DNS issues
    logger.info(f"Using direct connection to MongoDB with hostname: {hostname}")
    
    # Create a direct connection to MongoDB with optimized parameters from config
    mongo_client = pymongo.MongoClient(
        mongo_uri,
        maxPoolSize=Config.MONGO_MAX_POOL_SIZE,
        minPoolSize=Config.MONGO_MIN_POOL_SIZE,
        maxIdleTimeMS=Config.MONGO_MAX_IDLE_TIME_MS,
        serverSelectionTimeoutMS=Config.MONGO_SERVER_SELECTION_TIMEOUT_MS,
        connectTimeoutMS=Config.MONGO_CONNECT_TIMEOUT_MS,
        socketTimeoutMS=Config.MONGO_SOCKET_TIMEOUT_MS,
        retryWrites=True,
        retryReads=True,
        w='majority',                   # Ensure write acknowledgement
        waitQueueTimeoutMS=30000,       # Wait queue timeout
        directConnection=False          # Let MongoDB driver handle connection strategy
    )
    
    # Test the connection with longer timeout
    mongo_client.admin.command('ping', serverSelectionTimeoutMS=15000)
    logger.info("MongoDB connection successful!")
    
    # Configure connection error handling and reconnection mechanism
    mongo_client.MIN_RECONNECT_DELAY = 5  # seconds
    mongo_client.MAX_RECONNECT_DELAY = 30  # seconds
    
    # Get the database - specify the database name explicitly
    mongo_db = mongo_client[Config.MONGO_DB_NAME]
    
    # Verify the database connection by listing collections
    mongo_db.list_collection_names()
    logger.info(f"Connected to database: {Config.MONGO_DB_NAME}")
    
    # Create indexes for better performance
    try:
        mongo_db.users.create_index([('username', 1)], unique=True)
        mongo_db.payments.create_index([('checkout_id', 1)])
        mongo_db.transactions.create_index([('checkout_id', 1)])
        mongo_db.transactions.create_index([('real_checkout_id', 1)])
        mongo_db.transactions.create_index([('username', 1)])
        logger.info("MongoDB indexes created successfully")
    except Exception as idx_err:
        logger.warning(f"Error creating indexes: {str(idx_err)}")
    
    # Payment processor is initialized later before app starts
    
except Exception as e:
    logger.error(f"MongoDB connection error: {str(e)}")
    # Log more detailed information about the connection
    logger.error(f"MongoDB URI: {Config.MONGO_URI if hasattr(Config, 'MONGO_URI') else 'Not defined'}")
    logger.error(f"MongoDB DB Name: {Config.MONGO_DB_NAME if hasattr(Config, 'MONGO_DB_NAME') else 'Not defined'}")
    # Set flag to indicate we're using in-memory fallback
    config.USING_IN_MEMORY = True
    logger.warning("Using in-memory database fallback due to MongoDB connection failure")
    # Don't exit, let the application continue but with limited functionality

# Initialize database
init_db()

# Register support bot blueprint
register_support_bot(app)

# Check API status on startup
api_status = get_api_status()
logger.info(f"\nAPI Status: {api_status.get('status', 'unknown')}")
if api_status.get('status') != 'online':
    logger.warning(f"API is not fully operational: {api_status.get('message', 'Unknown error')}")

@app.route('/')
def index():
    """Redirect to the humanize page."""
    # Check if we're using in-memory fallback and show a warning flash message
    if hasattr(config, 'USING_IN_MEMORY') and config.USING_IN_MEMORY:
        flash("Database connection is currently unavailable. Using limited functionality mode.", "warning")
    return redirect(url_for('humanize'))

@app.route('/register', methods=['GET', 'POST'])
def register():
    """Handle user registration."""
    from datetime import datetime
    
    # Import form within the route to avoid circular imports
    from backend.payments.forms import RegistrationForm
    
    # If user is already logged in, redirect to dashboard
    if 'user_id' in session:
        return redirect(url_for('account'))
    
    # Create registration form
    form = RegistrationForm()
    
    if form.validate_on_submit():
        username = form.username.data
        password = form.password.data
        email = form.email.data
        phone_number = form.phone_number.data
        
        # Get the user's IP address
        ip_address = request.remote_addr
        
        # Explicitly import add_user in this scope
        from backend.db import add_user
        
        # Add user to database with IP tracking
        success, message = add_user(username, password, email, phone_number, ip_address)
        
        if success:
            flash('Registration successful! Please log in.', 'success')
            return redirect(url_for('login'))
        else:
            flash(f'Registration failed: {message}', 'danger')
    
    # GET request or form validation failed - display registration form
    return render_template('register.html', form=form)

@app.route('/login', methods=['GET', 'POST'])
def login():
    """Handle user login."""
    # Import form within the route to avoid circular imports
    from backend.payments.forms import LoginForm
    
    # If user is already logged in, redirect to dashboard
    if 'user_id' in session:
        return redirect(url_for('account'))
    
    # Create login form
    form = LoginForm()
    
    if form.validate_on_submit():
        username = form.username.data
        password = form.password.data
        
        # Explicitly import verify_user
        from backend.db import verify_user
        
        # Verify user credentials
        success, result = verify_user(username, password)
        
        if success:
            # Store user info in session
            session['user_id'] = username
            # Reset guest usage when logging in
            if 'guest_words_used' in session:
                session.pop('guest_words_used')
            
            # Get the user's IP address and add it to their list
            ip_address = request.remote_addr
            if ip_address:
                # Explicitly import the add_user_ip function
                from backend.db import add_user_ip
                ip_success, ip_message = add_user_ip(username, ip_address)
                if not ip_success:
                    # If they've hit their IP limit for their plan
                    flash(ip_message, 'warning')
            
            # Update last login time if MongoDB is available
            if mongo_db is not None:
                try:
                    mongo_db.users.update_one(
                        {'username': username},
                        {'$set': {'last_login': datetime.now()}}
                    )
                except Exception as e:
                    logger.error(f"Error updating last login time: {str(e)}")
            
            flash('Login successful!', 'success')
            
            # Redirect to the next page or humanize
            next_page = request.args.get('next')
            return redirect(next_page or url_for('humanize'))
        else:
            flash(f'Login failed: {result}', 'danger')
    
    # GET request or form validation failed - display login form
    return render_template('login.html', form=form)

@app.route('/logout')
def logout():
    """Handle user logout."""
    # Clear session data
    session.clear()
    flash('You have been logged out', 'info')
    return redirect(url_for('index'))

@app.route('/account')
def account():
    """Render the user account page."""
    from datetime import datetime
    
    # Check if user is logged in
    if 'user_id' not in session:
        flash('Please log in to access your account', 'warning')
        return redirect(url_for('login'))
    
    # Get user info
    user_id = session['user_id']
    user = get_user(user_id)
    
    # If user is None (not found), create a default user object for display
    if user is None:
        from datetime import datetime
        from config import SUBSCRIPTION_PLANS
        user = {
            "username": user_id,
            "email": "",
            "phone_number": "",
            "word_balance": {
                "total_allocation": SUBSCRIPTION_PLANS["free"]["words"],
                "remaining_words": SUBSCRIPTION_PLANS["free"]["words"],
                "words_used": 0,
                "last_reset": datetime.now()
            },
            "usage": {
                "requests": 0,
                "total_words": 0
            },
            "created_at": datetime.now()
        }
    
    # Get word balance - user is guaranteed to be non-None at this point due to the check above
    # but let's make the code more robust anyway
    from config import SUBSCRIPTION_PLANS
    
    if user:
        word_balance = user.get('word_balance', {
            "total_allocation": SUBSCRIPTION_PLANS["free"]["words"],
            "remaining_words": SUBSCRIPTION_PLANS["free"]["words"],
            "words_used": 0,
            "last_reset": datetime.now()
        })
    else:
        word_balance = {
            "total_allocation": SUBSCRIPTION_PLANS["free"]["words"],
            "remaining_words": SUBSCRIPTION_PLANS["free"]["words"],
            "words_used": 0,
            "last_reset": datetime.now()
        }
    
    # Get payment history if MongoDB is available
    payment_history = []
    active_transactions = []
    
    try:
        if mongo_db is not None:
            # Get payment history
            payment_history = list(mongo_db.payments.find({"username": user_id}).sort("timestamp", -1))
            
            # Get active transactions
            active_transactions = list(mongo_db.transactions.find({
                "username": user_id,
                "status": {"$in": ["queued", "pending", "processing"]}
            }).sort("timestamp", -1))
            
            # Add checkout_id to session if there's an active transaction
            if active_transactions and 'active_payment_id' not in session:
                session['active_payment_id'] = active_transactions[0].get('checkout_id')
                session['payment_timestamp'] = active_transactions[0].get('timestamp').strftime('%Y-%m-%d %H:%M:%S')
    except Exception as e:
        logger.error(f"Error fetching payment history: {str(e)}")
    
    # Render account template with user info
    return render_template('account.html', 
                         user=user, 
                         payment_history=payment_history, 
                         word_balance=word_balance,
                         active_transactions=active_transactions)

@app.route('/pricing')
def pricing():
    """Display pricing plans for subscriptions"""
    from datetime import datetime
    
    # Get user info if logged in
    current_plan = None
    word_balance = None
    expires_at = None
    
    if 'user_id' in session:
        user_id = session['user_id']
        user = get_user(user_id)
        
        if user:
            # Get current subscription details
            word_balance = user.get('word_balance', {})
            current_plan = word_balance.get('subscription_plan', 'free')
            expires_at = word_balance.get('expires_at')
    
    return render_template('pricing.html', 
                          subscription_plans=SUBSCRIPTION_PLANS, 
                          current_plan=current_plan,
                          word_balance=word_balance,
                          expires_at=expires_at)

@app.route('/subscribe/<plan_id>')
def subscribe(plan_id):
    """Process subscription request"""
    from datetime import datetime
    
    # Check if user is logged in
    if 'user_id' not in session:
        flash('Please log in to continue', 'warning')
        return redirect(url_for('login'))
    
    # Validate plan id
    if plan_id not in SUBSCRIPTION_PLANS:
        flash('Invalid subscription plan', 'danger')
        return redirect(url_for('pricing'))
    
    # Get plan details
    plan = SUBSCRIPTION_PLANS[plan_id]
    
    # Get user info and current plan
    user_id = session['user_id']
    user = get_user(user_id)
    current_plan = user.get('word_balance', {}).get('subscription_plan', 'free')
    
    # Check if user is trying to subscribe to their current plan
    if current_plan == plan_id:
        flash(f"You are already subscribed to the {plan.get('name', plan_id.title())} plan.", 'info')
        return redirect(url_for('pricing'))
    
    # If plan is free, allocate words directly
    if plan['price'] == 0:
        # For free plan, always reset words
        try:
            update_user_word_balance(user_id, str(plan_id), keep_existing=False)
        except Exception as e:
            logger.error(f"Error updating word balance for free plan: {str(e)}")
        flash('Your free word allocation has been applied!', 'success')
        return redirect(url_for('account'))
    
    # For paid plans, determine if we should keep existing words (only when upgrading)
    keep_existing = False
    if current_plan in ['free'] and plan_id in ['basic', 'premium', 'enterprise']:
        # Upgrading from free to any paid tier - reset words
        keep_existing = False
    elif current_plan == 'basic' and plan_id in ['premium', 'enterprise']:
        # Upgrading from basic to premium/enterprise - keep words
        keep_existing = True
    elif current_plan == 'premium' and plan_id == 'enterprise':
        # Upgrading from premium to enterprise - keep words
        keep_existing = True
    
    # Create payment with keep_existing flag
    session['keep_existing_words'] = keep_existing
    
    # For paid plans, redirect to payment processing
    return redirect(url_for('process_subscription', plan_id=plan_id))

@app.route('/process-subscription/<plan_id>')
def process_subscription(plan_id):
    """Process a subscription payment"""
    from datetime import datetime
    # Check if user is logged in
    if 'user_id' not in session:
        flash('Please log in to continue', 'warning')
        return redirect(url_for('login'))
    
    # Validate plan id
    if plan_id not in SUBSCRIPTION_PLANS:
        flash('Invalid subscription plan', 'danger')
        return redirect(url_for('pricing'))
    
    # Get plan details
    plan = SUBSCRIPTION_PLANS[plan_id]
    amount = plan['price']
    
    # Get callback URL
    callback_url = get_callback_url()
    logger.info(f"Using callback URL: {callback_url}")
    
    # Get username from session
    username = session['user_id']
    
    # Initiate payment asynchronously
    checkout_id, message, success = initiate_payment_async(
        mongo_db,
        username,
        amount,
        plan_id,
        callback_url
    )
    
    if success:
        # Store the checkout ID in session for tracking
        session['active_payment_id'] = checkout_id
        session['payment_timestamp'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        
        # Render payment processing template
        return render_template('payment_processing.html', 
                             checkout_id=checkout_id,
                             plan=plan,
                             amount=amount,
                             currency=Config.CURRENCY)
    else:
        # Payment failed or error occurred
        flash(f'Payment processing failed: {message}', 'danger')
        return redirect(url_for('pricing'))

@app.route('/payment-callback', methods=['POST'])
def payment_callback():
    """Handle payment callbacks from payment API"""
    try:
        # Get and log the callback data
        callback_data = request.json
        logger.info(f"Received payment callback: {callback_data}")
        
        # Process the callback
        success, message = process_payment_callback(mongo_db, callback_data)
        
        # Return appropriate response
        if success:
            return jsonify({'status': 'success', 'message': message}), 200
        else:
            return jsonify({'status': 'error', 'message': message}), 400
    except Exception as e:
        logger.error(f"Error handling payment callback: {str(e)}")
        return jsonify({'status': 'error', 'message': str(e)}), 500

@app.route('/check-payment-status/<checkout_id>')
def check_payment_status(checkout_id):
    """Check payment status for AJAX polling"""
    try:
        # Get current user's username if authenticated
        username = session['user_id'] if 'user_id' in session else None
        
        # Check transaction status
        status_data = get_transaction_status(mongo_db, checkout_id, username)
        
        # Return status data
        return jsonify(status_data)
    except Exception as e:
        logger.error(f"Error checking payment status: {str(e)}")
        return jsonify({
            'status': 'error',
            'message': f'Error checking payment status: {str(e)}'
        })

@app.route('/cancel-payment/<checkout_id>')
def cancel_payment(checkout_id):
    """Cancel a pending payment"""
    from datetime import datetime
    # Check if user is logged in
    if 'user_id' not in session:
        flash('Please log in to continue', 'warning')
        return redirect(url_for('login'))
    
    try:
        username = session['user_id']
        
        # Check if MongoDB is available
        if mongo_db is None:
            flash('Database connection is not available. Please try again later.', 'danger')
            return redirect(url_for('account'))
            
        # Get transaction
        transaction = mongo_db.transactions.find_one({'checkout_id': checkout_id})
        
        if not transaction:
            # Try with real_checkout_id
            transaction = mongo_db.transactions.find_one({'real_checkout_id': checkout_id})
            
        if not transaction:
            flash('Transaction not found.', 'danger')
            return redirect(url_for('account'))
        
        # Check if user is authorized to cancel this transaction
        if transaction['username'] != username:
            flash('You are not authorized to cancel this payment.', 'danger')
            return redirect(url_for('account'))
        
        # Check if transaction can be cancelled
        if transaction['status'] not in ['queued', 'pending', 'processing']:
            flash(f'Cannot cancel payment with status: {transaction["status"]}', 'warning')
            return redirect(url_for('account'))
        
        # Update transaction status
        mongo_db.transactions.update_one(
            {'_id': transaction['_id']},
            {'$set': {
                'status': 'cancelled',
                'error': 'Cancelled by user',
                'updated_at': datetime.now()
            }}
        )
        
        # Update payment status
        mongo_db.payments.update_one(
            {'checkout_id': checkout_id},
            {'$set': {
                'status': 'cancelled',
                'reference': 'Cancelled by user'
            }}
        )
            
        # Clear session tracking
        if 'active_payment_id' in session and session['active_payment_id'] == checkout_id:
            session.pop('active_payment_id', None)
            session.pop('payment_timestamp', None)
            
        flash('Payment has been cancelled.', 'info')
        return redirect(url_for('account'))
    except Exception as e:
        logger.error(f"Error cancelling payment: {str(e)}")
        flash(f'Error cancelling payment: {str(e)}', 'danger')
        return redirect(url_for('account'))

@app.route('/verify-payment/<checkout_id>')
def verify_payment(checkout_id):
    """Manually verify a payment status and update if completed"""
    try:
        # Get current user's username if authenticated
        username = session['user_id'] if 'user_id' in session else None
        if not username:
            return jsonify({
                'status': 'error',
                'message': 'You must be logged in to verify payments'
            }), 401
        
        # Check if MongoDB is available
        if mongo_db is None:
            return jsonify({
                'status': 'error',
                'message': 'Database connection is unavailable'
            }), 500
            
        # Get transaction - try both checkout_id and real_checkout_id
        transaction = mongo_db.transactions.find_one({'checkout_id': checkout_id})
        if not transaction:
            transaction = mongo_db.transactions.find_one({'real_checkout_id': checkout_id})
            
        if not transaction:
            return jsonify({
                'status': 'error',
                'message': 'Transaction not found'
            }), 404
        
        # Check if user is authorized to view this transaction
        if transaction['username'] != username:
            return jsonify({
                'status': 'error',
                'message': 'You are not authorized to view this payment'
            }), 403
            
        # Check current transaction status
        current_status = transaction.get('status')
        
        # If the transaction is already complete, return success immediately
        if current_status == 'completed':
            # Clear session tracking
            if 'active_payment_id' in session:
                session.pop('active_payment_id', None)
                session.pop('payment_timestamp', None)
                
            return jsonify({
                'status': 'success',
                'message': 'Payment has been completed',
                'redirect': url_for('account')
            })
            
        # If the transaction is still pending or processing, check status again
        elif current_status in ['pending', 'processing', 'queued']:
            # Try to update the status one more time
            from backend.payments import get_transaction_status
            status_data = get_transaction_status(mongo_db, checkout_id, username)
            
            # If the status is now completed, report success
            if status_data.get('status') == 'completed':
                # Clear session tracking
                if 'active_payment_id' in session:
                    session.pop('active_payment_id', None)
                    session.pop('payment_timestamp', None)
                    
                return jsonify({
                    'status': 'success',
                    'message': 'Payment has been completed',
                    'redirect': url_for('account')
                })
            else:
                # Still not completed
                return jsonify({
                    'status': 'pending',
                    'message': f"Payment is still {status_data.get('status')}. Please check your payment app or try again."
                })
        else:
            # Payment has failed, been cancelled, etc.
            return jsonify({
                'status': 'error',
                'message': f"Payment status is {current_status}. Please try again or contact support."
            })
    except Exception as e:
        logger.error(f"Error verifying payment: {str(e)}")
        return jsonify({
            'status': 'error',
            'message': f'Error verifying payment: {str(e)}'
        }), 500

@app.route('/payment-success/<checkout_id>')
def payment_success(checkout_id):
    """Handle payment success"""
    from datetime import datetime, timedelta
    
    # Check if user is logged in
    if 'user_id' not in session:
        flash('Please log in to continue', 'warning')
        return redirect(url_for('login'))
    
    try:
        username = session['user_id']
        
        # Check if MongoDB is available
        if mongo_db is None:
            flash('Database connection is not available. Please try again later.', 'danger')
            return redirect(url_for('account'))
            
        # Get transaction - try both checkout_id and real_checkout_id
        transaction = mongo_db.transactions.find_one({'checkout_id': checkout_id})
        if not transaction:
            transaction = mongo_db.transactions.find_one({'real_checkout_id': checkout_id})
            
        if not transaction:
            flash('Transaction not found.', 'danger')
            return redirect(url_for('account'))
        
        # Check if user is authorized to view this transaction
        if transaction['username'] != username:
            flash('You are not authorized to view this payment.', 'danger')
            return redirect(url_for('account'))
        
        # Check if transaction is successful
        if transaction['status'] != 'completed':
            flash(f'Payment is not completed. Current status: {transaction["status"]}', 'warning')
            return redirect(url_for('account'))
        
        # Clear session tracking
        if 'active_payment_id' in session:
            session.pop('active_payment_id', None)
            session.pop('payment_timestamp', None)
        
        # Get subscription plan
        subscription_type = transaction['subscription_type']
        amount = transaction['amount']
        
        # Check if we need to keep existing words
        keep_existing = session.pop('keep_existing_words', False)
        
        # Update user's subscription
        try:
            success = update_user_word_balance(username, str(subscription_type), keep_existing=keep_existing)
        except Exception as e:
            logger.error(f"Error updating word balance for subscription callback: {str(e)}")
            success = False
        
        if success:
            # Get plan name
            plan_name = SUBSCRIPTION_PLANS[subscription_type].get('name', subscription_type.title())
            word_count = SUBSCRIPTION_PLANS[subscription_type]['words']
            
            # Show success message indicating whether words were kept or reset
            if keep_existing:
                flash(f'Your payment for {plan_name} was successful! {word_count} words have been added to your existing balance. Your subscription is active until {datetime.now().replace(microsecond=0) + timedelta(days=30)}', 'success')
            else:
                flash(f'Your payment for {plan_name} was successful! Your balance has been set to {word_count} words. Your subscription is active until {datetime.now().replace(microsecond=0) + timedelta(days=30)}', 'success')
        else:
            flash('Payment was successful but we encountered an error updating your subscription. Please contact support.', 'warning')
            
        return redirect(url_for('account'))
        
    except Exception as e:
        logger.error(f"Error showing payment success: {str(e)}")
        flash(f'Error showing payment success: {str(e)}', 'danger')
        return redirect(url_for('account'))

@app.route('/payment-failed/<checkout_id>')
def payment_failed(checkout_id):
    """Handle payment failure"""
    # Check if user is logged in
    if 'user_id' not in session:
        flash('Please log in to continue', 'warning')
        return redirect(url_for('login'))
    
    try:
        username = session['user_id']
        
        # Check if MongoDB is available
        if mongo_db is None:
            flash('Database connection is not available. Please try again later.', 'danger')
            return redirect(url_for('account'))
            
        # Get transaction - try both checkout_id and real_checkout_id
        transaction = mongo_db.transactions.find_one({'checkout_id': checkout_id})
        if not transaction:
            transaction = mongo_db.transactions.find_one({'real_checkout_id': checkout_id})
            
        if not transaction:
            flash('Transaction not found.', 'danger')
            return redirect(url_for('account'))
        
        # Check if user is authorized to view this transaction
        if transaction['username'] != username:
            flash('You are not authorized to view this payment.', 'danger')
            return redirect(url_for('account'))
        
        # Check if transaction has failed
        if transaction['status'] not in ['failed', 'timeout', 'cancelled', 'error']:
            flash(f'Payment has not failed. Current status: {transaction["status"]}', 'warning')
            return redirect(url_for('account'))
        
        # Clear session tracking
        if 'active_payment_id' in session:
            session.pop('active_payment_id', None)
            session.pop('payment_timestamp', None)
        
        # Show failure message directly on dashboard
        reason = transaction.get('error', 'Unknown reason')
        flash(f'Payment failed: {reason}. Please try again or contact support if the issue persists.', 'danger')
        return redirect(url_for('account'))
        
    except Exception as e:
        logger.error(f"Error showing payment failure: {str(e)}")
        flash(f'Error showing payment failure: {str(e)}', 'danger')
        return redirect(url_for('account'))

@app.route('/humanize', methods=['GET', 'POST'])
def humanize():
    """Handle text humanization requests for both logged-in and guest users."""
    from datetime import datetime
    import json
    
    # Initialize word balance with guest values or logged-in user values
    from config import SUBSCRIPTION_PLANS, GUEST_LIMITS
    
    if 'user_id' in session:
        # User is logged in - get their word balance
        user_id = session['user_id']
        user = get_user(user_id)
        # Handle case where user might be None
        if user is None:
            word_balance = {
                "total_allocation": SUBSCRIPTION_PLANS["free"]["words"],
                "remaining_words": SUBSCRIPTION_PLANS["free"]["words"],
                "words_used": 0,
                "last_reset": datetime.now(),
                "subscription_plan": "free",
                "per_request_limit": SUBSCRIPTION_PLANS["free"]["per_request_limit"]
            }
        else:
            word_balance = user.get('word_balance', {
                "total_allocation": SUBSCRIPTION_PLANS["free"]["words"],
                "remaining_words": SUBSCRIPTION_PLANS["free"]["words"],
                "words_used": 0,
                "last_reset": datetime.now(),
                "subscription_plan": "free",
                "per_request_limit": SUBSCRIPTION_PLANS["free"]["per_request_limit"]
            })
            
            # Check if subscription has expired
            if word_balance.get("expires_at") and word_balance["expires_at"] < datetime.now() and word_balance["subscription_plan"] != "free":
                # Subscription expired - reset to free plan
                flash("Your subscription has expired. You have been downgraded to the free plan.", "warning")
                try:
                    update_user_word_balance(user_id, "free", keep_existing=False)
                except Exception as e:
                    logger.error(f"Error updating word balance when subscription expired: {str(e)}")
                word_balance = {
                    "total_allocation": SUBSCRIPTION_PLANS["free"]["words"],
                    "remaining_words": SUBSCRIPTION_PLANS["free"]["words"],
                    "words_used": 0,
                    "last_reset": datetime.now(),
                    "subscription_plan": "free",
                    "per_request_limit": SUBSCRIPTION_PLANS["free"]["per_request_limit"]
                }
                
        is_guest = False
        # Get plan details
        subscription_plan = word_balance.get("subscription_plan", "free")
        plan = SUBSCRIPTION_PLANS.get(subscription_plan, SUBSCRIPTION_PLANS["free"])
        # Handle comma-formatted strings when getting per_request_limit
        per_request_limit_raw = word_balance.get("per_request_limit", plan.get("per_request_limit", 300))
        # If it's a string with commas, use the count version or convert safely
        if isinstance(per_request_limit_raw, str) and ',' in per_request_limit_raw:
            per_request_limit = plan.get("per_request_limit_count", safe_int_convert(per_request_limit_raw))
        else:
            per_request_limit = safe_int_convert(per_request_limit_raw)
    else:
        # Guest user - initialize or get their limited word balance
        if 'guest_words_used' not in session:
            session['guest_words_used'] = 0
        
        # Calculate remaining words for guest
        guest_words_used = session.get('guest_words_used', 0)
        guest_words_remaining = max(0, GUEST_LIMITS["total_words"] - guest_words_used)
        
        word_balance = {
            "total_allocation": GUEST_LIMITS["total_words"],
            "remaining_words": guest_words_remaining,
            "words_used": guest_words_used,
            "last_reset": datetime.now(),
            "subscription_plan": "guest",
            "per_request_limit": GUEST_LIMITS["max_per_request"]
        }
        is_guest = True
        per_request_limit = GUEST_LIMITS["max_per_request"]
    
    if request.method == 'POST':
        # Get original text and options from form
        original_text = request.form.get('original_text', '')
        html_content = request.form.get('html_content', '')
        text_selections = request.form.get('text_selections', '')
        format_preserved_elements = request.form.get('format_preserved_elements', '')

        # Check if file was uploaded
        uploaded_file = None
        if 'file_upload' in request.files:
            uploaded_file = request.files['file_upload']
            if uploaded_file.filename != '':
                # Process file content (handled by frontend JavaScript)
                pass
        
        # Parse preservation settings
        preservation_settings = {}
        if format_preserved_elements:
            try:
                preservation_settings = json.loads(format_preserved_elements)
            except Exception as e:
                logger.error(f"Error parsing format preservation settings: {str(e)}")
        
        # Extract preservation options
        preserve_quotes = 'preserve_quotes' in request.form or \
                        (preservation_settings.get('preserve_quotes', False) if preservation_settings else False)
        preserve_bold = preservation_settings.get('preserve_bold', False) if preservation_settings else False
        preserve_headings = preservation_settings.get('preserve_headings', False) if preservation_settings else False
        preserve_links = preservation_settings.get('preserve_links', False) if preservation_settings else False
        preserve_images = preservation_settings.get('preserve_images', False) if preservation_settings else False
        preserve_lists = preservation_settings.get('preserve_lists', False) if preservation_settings else False
        custom_elements = preservation_settings.get('custom_elements', '') if preservation_settings else ''
        preservation_level = preservation_settings.get('preservation_level', 'medium') if preservation_settings else 'medium'
        humanization_strength = preservation_settings.get('humanization_strength', 'moderate') if preservation_settings else 'moderate'
        
        # Check for text selections
        selected_ranges = []
        if text_selections:
            try:
                selected_ranges = json.loads(text_selections)
                logger.info(f"Processing {len(selected_ranges)} text selections")
            except Exception as e:
                logger.error(f"Error parsing text selections: {str(e)}")
        
        if not original_text:
            flash('Please enter text to humanize', 'warning')
            return render_template('humanize.html', word_balance=word_balance, is_guest=is_guest)
        
        # Count words and ensure it's an integer
        word_count = safe_int_convert(count_words(original_text))
        
        # Check word limits based on user type
        if is_guest:
            # Guest user limits
            # Check if exceeding per-request limit
            if word_count > safe_int_convert(per_request_limit):
                flash(f"As a guest user, you can humanize up to {per_request_limit} words per request. Please register for unlimited access.", 'warning')
                return render_template('humanize.html', 
                                    original_text=original_text, 
                                    word_count=word_count, 
                                    word_balance=word_balance, 
                                    is_guest=is_guest,
                                    preserve_quotes=preserve_quotes,
                                    guest_limits=GUEST_LIMITS)
            
            # Check if exceeding total words limit - handle possible string values safely
            remaining_words = safe_int_convert(word_balance["remaining_words"])
            if word_count > remaining_words:
                flash(f"You've reached your guest word limit of {GUEST_LIMITS['total_words']} words. Please register for unlimited access.", 'warning')
                return render_template('humanize.html', 
                                    original_text=original_text, 
                                    word_count=word_count, 
                                    word_balance=word_balance, 
                                    is_guest=is_guest, 
                                    preserve_quotes=preserve_quotes,
                                    show_register=True,
                                    guest_limits=GUEST_LIMITS)
        else:
            # Registered user limits based on subscription plan
            # Check if exceeding per-request limit
            if word_count > safe_int_convert(per_request_limit):
                plan_name = SUBSCRIPTION_PLANS.get(subscription_plan, {}).get("name", subscription_plan.title())
                upgrade_message = ""
                
                # Suggest appropriate plan upgrade
                for plan_id, plan_details in SUBSCRIPTION_PLANS.items():
                    # Use per_request_limit_count if available, otherwise safely convert the string
                    plan_limit = plan_details.get("per_request_limit_count", 0)
                    if not plan_limit and plan_details.get("per_request_limit"):
                        # Handle string with commas using our safe conversion utility
                        plan_limit = safe_int_convert(plan_details.get("per_request_limit", 0))
                        
                    if plan_limit >= word_count and plan_id != subscription_plan:
                        upgrade_message = f" Consider upgrading to the {plan_details.get('name', plan_id.title())} to process up to {plan_details.get('per_request_limit')} words per request."
                        break
                        
                flash(f"Your current {plan_name} allows up to {per_request_limit} words per request. This text has {word_count} words.{upgrade_message}", 'warning')
                return render_template('humanize.html', 
                                    original_text=original_text, 
                                    word_count=word_count, 
                                    word_balance=word_balance, 
                                    is_guest=is_guest,
                                    preserve_quotes=preserve_quotes,
                                    subscription_plan=subscription_plan)
            
            # Check if exceeding remaining words - handle possible string values safely
            remaining_words = safe_int_convert(word_balance.get("remaining_words", 0))
            if word_count > remaining_words:
                flash(f"You don't have enough words remaining in your account. You have {word_balance.get('remaining_words', 0)} words but this text requires {word_count} words.", 'warning')
                return render_template('humanize.html', 
                                    original_text=original_text, 
                                    word_count=word_count, 
                                    word_balance=word_balance, 
                                    is_guest=is_guest,
                                    preserve_quotes=preserve_quotes,
                                    subscription_plan=subscription_plan,
                                    show_subscription=True)
        
        try:
            # For guest users, use a generic ID
            api_user_id = session.get('user_id', 'guest_user')
            
            # Log request for debugging
            logger.info(f"Humanizing text - User: {api_user_id}, Word count: {word_count}, Plan limit: {per_request_limit}")
            
            # Process based on whether text selections are present
            if selected_ranges and len(selected_ranges) > 0:
                logger.info(f"Selective humanization with {len(selected_ranges)} ranges")
                # Use the HTML content for selective humanization
                from backend.api_service import humanize_selected_text
                
                # Call the selective humanization function
                result = humanize_selected_text(
                    html_content or original_text,  # Use HTML content if available, otherwise original text
                    selected_ranges, 
                    api_user_id,
                    preserve_formatting=True,
                    preserve_quotes=preserve_quotes,
                    preserve_bold=preserve_bold,
                    preserve_headings=preserve_headings,
                    preserve_links=preserve_links,
                    preserve_images=preserve_images,
                    preserve_lists=preserve_lists,
                    custom_elements=custom_elements,
                    preservation_level=preservation_level,
                    humanization_strength=humanization_strength
                )
            else:
                # Call the API through our backend service for the entire text
                result = humanize_text(original_text, api_user_id, 
                                    preserve_quotes=preserve_quotes,
                                    preserve_formatting=True,
                                    preserve_bold=preserve_bold,
                                    preserve_headings=preserve_headings,
                                    preserve_links=preserve_links,
                                    preserve_images=preserve_images,
                                    preserve_lists=preserve_lists,
                                    custom_elements=custom_elements,
                                    preservation_level=preservation_level,
                                    humanization_strength=humanization_strength)
            humanized_text = result.get('humanized_text', '')
            
            # Log success and response metrics
            logger.info(f"Humanize successful - Length of response: {len(humanized_text)}, Metrics: {result.get('metrics', {})}")
            
            # Update word usage stats
            if is_guest:
                # Update guest usage
                session['guest_words_used'] = guest_words_used + word_count
                # Recalculate guest word balance
                word_balance["words_used"] = session['guest_words_used']
                word_balance["remaining_words"] = max(0, GUEST_LIMITS["total_words"] - session['guest_words_used'])
            else:
                # Update registered user usage and deduct from remaining words
                user = get_user(api_user_id)
                if user:
                    current_balance = user.get('word_balance', {})
                    # Safely convert values to avoid type errors
                    current_remaining = safe_int_convert(current_balance.get('remaining_words', 0))
                    current_used = safe_int_convert(current_balance.get('words_used', 0))
                    
                    # Calculate new values
                    remaining_words = max(0, current_remaining - word_count)
                    words_used = current_used + word_count
                    
                    # Update the database - using directly imported users_collection
                    from backend.db import users_collection
                    users_collection.update_one(
                        {"username": api_user_id},
                        {"$set": {
                            "word_balance.remaining_words": remaining_words,
                            "word_balance.words_used": words_used,
                            "usage.requests": safe_int_convert(user.get('usage', {}).get('requests', 0)) + 1,
                            "usage.total_words": safe_int_convert(user.get('usage', {}).get('total_words', 0)) + word_count,
                            "usage.last_request": datetime.now()
                        }}
                    )
                    
                    # Update word balance for display
                    word_balance['remaining_words'] = remaining_words
                    word_balance['words_used'] = words_used
            
            # Prepare success message
            message = "Text humanized successfully!"
            message_type = "success"
            
            # Get metrics
            metrics = result.get('metrics', {})
            api_response_time = metrics.get('response_time', None)
            api_source = "External API"
            
            # Check if user has used up all their words
            show_register = is_guest and word_balance["remaining_words"] <= 0
            show_subscription = not is_guest and word_balance["remaining_words"] <= 100  # Show subscription options when running low
            
            # Use the enhanced template if specified in query parameter
            use_enhanced = request.args.get('enhanced', 'false').lower() == 'true'
            template_name = 'humanize_enhanced_new.html' if use_enhanced else 'humanize.html'
            
            # Render the template with results
            return render_template(template_name,
                                original_text=original_text,
                                humanized_text=humanized_text,
                                metrics=metrics,
                                message=message,
                                message_type=message_type,
                                api_source=api_source,
                                api_response_time=api_response_time,
                                word_count=word_count,
                                word_balance=word_balance,
                                is_guest=is_guest,
                                preserve_quotes=preserve_quotes,
                                preserve_bold=preserve_bold,
                                preserve_headings=preserve_headings,
                                preserve_links=preserve_links,
                                preserve_images=preserve_images,
                                preserve_lists=preserve_lists,
                                show_register=show_register,
                                show_subscription=show_subscription,
                                subscription_plan=None if is_guest else subscription_plan,
                                guest_limits=GUEST_LIMITS if is_guest else None)
                                  
        except HumanizerAPIError as e:
            # API error
            message = f"API Error: {str(e)}"
            flash(message, 'danger')
            
            # Use the enhanced template if specified in query parameter
            use_enhanced = request.args.get('enhanced', 'false').lower() == 'true'
            template_name = 'humanize_enhanced_new.html' if use_enhanced else 'humanize.html'
            
            return render_template(template_name, 
                                original_text=original_text,
                                message=message,
                                message_type="danger",
                                word_count=word_count,
                                word_balance=word_balance,
                                is_guest=is_guest,
                                preserve_quotes=preserve_quotes,
                                preserve_bold=preserve_bold,
                                preserve_headings=preserve_headings,
                                preserve_links=preserve_links,
                                preserve_images=preserve_images,
                                preserve_lists=preserve_lists,
                                guest_limits=GUEST_LIMITS if is_guest else None,
                                subscription_plan=None if is_guest else subscription_plan)
        except Exception as e:
            # Unexpected error
            message = f"Unexpected error: {str(e)}"
            flash(message, 'danger')
            
            # Use the enhanced template if specified in query parameter
            use_enhanced = request.args.get('enhanced', 'false').lower() == 'true'
            template_name = 'humanize_enhanced_new.html' if use_enhanced else 'humanize.html'
            
            return render_template(template_name, 
                                original_text=original_text,
                                message=message,
                                message_type="danger",
                                word_count=word_count,
                                word_balance=word_balance,
                                is_guest=is_guest,
                                preserve_quotes=preserve_quotes,
                                preserve_bold=preserve_bold,
                                preserve_headings=preserve_headings,
                                preserve_links=preserve_links,
                                preserve_images=preserve_images,
                                preserve_lists=preserve_lists,
                                guest_limits=GUEST_LIMITS if is_guest else None,
                                subscription_plan=None if is_guest else subscription_plan)
    
    # GET request - display humanize form
    # Use the enhanced template if specified in query parameter
    use_enhanced = request.args.get('enhanced', 'false').lower() == 'true'
    template_name = 'humanize_enhanced_new.html' if use_enhanced else 'humanize.html'
    
    return render_template(template_name, 
                        word_balance=word_balance, 
                        is_guest=is_guest,
                        preserve_quotes=False,
                        guest_limits=GUEST_LIMITS if is_guest else None,
                        subscription_plan=None if is_guest else subscription_plan)

@app.route('/api/word-count', methods=['POST'])
def api_word_count():
    """API endpoint to count words in text."""
    # Get the text from the request
    data = request.json
    text = data.get('text', '')
    
    # Count words
    word_count = count_words(text)
    
    # Return word count
    return jsonify({
        'word_count': word_count
    })

@app.route('/api/detect-ai', methods=['POST'])
def api_detect_ai():
    """API endpoint to detect AI-generated content."""
    from datetime import datetime
    # Get the text from the request
    data = request.json
    text = data.get('text', '')
    
    if not text:
        return jsonify({
            'error': 'No text provided'
        }), 400
    
    # Check guest vs registered users
    is_guest = 'user_id' not in session
    
    if is_guest:
        # Get guest word usage
        guest_words_used = session.get('guest_words_used', 0)
        guest_words_remaining = max(0, GUEST_LIMITS["total_words"] - guest_words_used)
        
        # Count words in the text
        word_count = count_words(text)
        
        # Check if exceeding guest limits
        if word_count > GUEST_LIMITS["max_per_request"]:
            return jsonify({
                'error': f"As a guest user, you can analyze up to {GUEST_LIMITS['max_per_request']} words per request. Please register for unlimited access.",
                'limit_reached': True,
                'type': 'request_limit'
            }), 403
        
        if word_count > guest_words_remaining:
            return jsonify({
                'error': f"You've reached your guest word limit of {GUEST_LIMITS['total_words']} words. Please register for unlimited access.",
                'limit_reached': True,
                'type': 'total_limit'
            }), 403
        
        # Update guest usage
        session['guest_words_used'] = guest_words_used + word_count
    else:
        # Registered user - no limits to check
        user_id = session['user_id']
        word_count = count_words(text)
        # Track usage for registered users
        update_user_word_usage(user_id, word_count)
    
    # In a real implementation, you would call an AI detection service
    # For this demo, we'll implement a simple but more realistic detection algorithm
    
    # Count words and get text stats
    word_count = count_words(text)
    
    # Base factors that might indicate AI writing
    ai_indicators = {
        'long_sentences': 0,
        'complex_words': 0,
        'repetition': 0,
        'perfect_grammar': 0,
        'unnaturally_structured': 0
    }
    
    # Analyze sentence length (longer sentences can be an AI indicator)
    sentences = text.split('.')
    avg_sentence_length = sum(len(s.split()) for s in sentences if s.strip()) / max(1, len(sentences))
    if avg_sentence_length > 15:
        ai_indicators['long_sentences'] = min(100, avg_sentence_length * 2)
    
    # Check for complex words and academic language
    complex_word_patterns = ['therefore', 'furthermore', 'however', 'additionally', 'nevertheless', 'subsequently']
    complex_count = sum(1 for word in complex_word_patterns if word.lower() in text.lower())
    ai_indicators['complex_words'] = min(100, complex_count * 15)
    
    # Check for repetition (AIs sometimes repeat phrases)
    words = text.lower().split()
    unique_words = len(set(words))
    if len(words) > 0:
        word_diversity = unique_words / len(words)
        # Lower diversity means more repetition
        ai_indicators['repetition'] = min(100, (1 - word_diversity) * 150)
    
    # Perfect grammar indicator (more common in AI text)
    grammar_errors = 0
    ai_indicators['perfect_grammar'] = min(100, (100 - grammar_errors * 20))
    
    # Structure analysis - placeholder for more complex implementation
    if word_count > 100:
        ai_indicators['unnaturally_structured'] = random.randint(40, 70)
    else:
        ai_indicators['unnaturally_structured'] = random.randint(20, 50)
    
    # Calculate weighted score
    weights = {
        'long_sentences': 0.2,
        'complex_words': 0.25,
        'repetition': 0.2,
        'perfect_grammar': 0.15,
        'unnaturally_structured': 0.2
    }
    
    ai_score = sum(ai_indicators[factor] * weights[factor] for factor in ai_indicators)
    
    # Add some randomness to make it less predictable
    ai_score = ai_score * 0.8 + random.randint(0, 20)
    
    # Final AI score
    ai_score = min(max(ai_score, 0), 100)
    
    # Round to integer
    ai_score = round(ai_score)
    
    # Add a small delay to simulate processing
    import time
    time.sleep(1.5)
    
    # Return the AI detection score with detailed breakdown
    return jsonify({
        'ai_score': ai_score,
        'analyzed_at': datetime.now().isoformat(),
        'word_count': word_count,
        'analysis': {
            'factors': {
                'Sentence Length': round(ai_indicators['long_sentences']),
                'Academic Language': round(ai_indicators['complex_words']),
                'Word Repetition': round(ai_indicators['repetition']),
                'Grammar Perfection': round(ai_indicators['perfect_grammar']),
                'Content Structure': round(ai_indicators['unnaturally_structured'])
            },
            'sentence_count': len(sentences),
            'avg_sentence_length': round(avg_sentence_length, 1),
            'vocabulary_diversity': round(unique_words / max(1, len(words)) * 100)
        }
    })

@app.route('/debug')
def debug():
    """Debug endpoint to show application state."""
    # Only available in development mode
    if os.environ.get('FLASK_ENV') != 'production':
        # Get all registered users
        users = []
        
        # Current user info
        user_info = None
        if 'user_id' in session:
            user_id = session['user_id']
            user = get_user(user_id)
            if user:
                user_info = {
                    'username': user.get('username', user_id),
                    'email': user.get('email', 'unknown'),
                    'usage': user.get('usage', {})
                }
        
        # API status
        api_status = get_api_status()
        
        # Session data
        session_data = dict(session)
        
        # MongoDB connection status
        mongodb_status = {
            'connected': mongo_client is not None,
            'in_memory_fallback': hasattr(config, 'USING_IN_MEMORY') and config.USING_IN_MEMORY,
            'database_name': Config.MONGO_DB_NAME if hasattr(Config, 'MONGO_DB_NAME') else 'unknown',
            'uri': Config.MONGO_URI.replace(Config.MONGO_URI.split('@')[0], '***:***') if hasattr(Config, 'MONGO_URI') else 'unknown',
        }
        
        # Test MongoDB connection if it exists
        if mongodb_status['connected']:
            try:
                # Test the connection with a fast ping command
                mongo_client.admin.command('ping', serverSelectionTimeoutMS=1000)
                mongodb_status['ping_success'] = True
                
                # Get database collections
                mongodb_status['collections'] = list(mongo_db.list_collection_names())
                mongodb_status['user_count'] = mongo_db.users.count_documents({}) if 'users' in mongodb_status['collections'] else 0
            except Exception as e:
                mongodb_status['ping_success'] = False
                mongodb_status['error'] = str(e)
        
        # Return debug information
        return render_template('debug.html',
                              user_info=user_info,
                              session=session_data,
                              api_status=api_status,
                              mongodb_status=mongodb_status)
    else:
        return "Debug endpoint not available in production", 404
        
@app.route('/status')
def status():
    """Simple status endpoint to check if the server is running and database connection."""
    from datetime import datetime
    status_info = {
        'app_status': 'online',
        'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'db_connection': 'connected' if mongo_client is not None else 'disconnected',
        'using_in_memory': hasattr(config, 'USING_IN_MEMORY') and config.USING_IN_MEMORY,
        'api_status': get_api_status().get('status', 'unknown')
    }
    
    # Check MongoDB connection if it exists
    if mongo_client:
        try:
            # Test ping with short timeout
            mongo_client.admin.command('ping', serverSelectionTimeoutMS=2000)
            status_info['db_ping'] = 'success'
            
            # Add database name
            status_info['db_name'] = Config.MONGO_DB_NAME
            
            # Try to access the database to verify it works
            if mongo_db:
                # Check if we can list collections
                try:
                    collections = list(mongo_db.list_collection_names())
                    status_info['collections'] = collections
                    status_info['collection_count'] = len(collections)
                except Exception as coll_err:
                    status_info['collections_error'] = str(coll_err)
        except Exception as e:
            status_info['db_ping'] = 'failed'
            status_info['db_error'] = str(e)
    
    return jsonify(status_info)

@app.route('/db-status')
def db_status():
    """Detailed MongoDB status endpoint with more diagnostic information."""
    from datetime import datetime
    # This endpoint should only be accessible in development mode
    if os.environ.get('FLASK_ENV') == 'production':
        return jsonify({"error": "This endpoint is not available in production mode."}), 403
    
    try:
        # Get MongoDB status
        mongodb_status = {
            'connected': mongo_client is not None,
            'in_memory_fallback': hasattr(config, 'USING_IN_MEMORY') and config.USING_IN_MEMORY,
            'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'db_name': Config.MONGO_DB_NAME,
            'mongo_uri': Config.MONGO_URI.split('@')[0] + '@' + Config.MONGO_URI.split('@')[1],  # Hide credentials
        }
        
        # DNS resolution check
        try:
            hostname = Config.MONGO_URI.split('@')[-1].split('/')[0]
            if '?' in hostname:
                hostname = hostname.split('?')[0]
                
            import socket
            mongodb_status['hostname'] = hostname
            ip = socket.gethostbyname(hostname)
            mongodb_status['dns_resolution'] = {
                'success': True,
                'ip': ip
            }
        except Exception as dns_error:
            mongodb_status['dns_resolution'] = {
                'success': False,
                'error': str(dns_error)
            }
        
        # Test MongoDB connection
        if mongo_client:
            try:
                # Ping the server with a short timeout
                start_time = time.time()
                mongo_client.admin.command('ping', serverSelectionTimeoutMS=2000)
                ping_time = (time.time() - start_time) * 1000  # in milliseconds
                
                mongodb_status['ping'] = {
                    'success': True,
                    'latency_ms': round(ping_time, 2)
                }
                
                # Database stats
                if mongo_db:
                    # List collections
                    collections = list(mongo_db.list_collection_names())
                    mongodb_status['collections'] = collections
                    
                    # Basic stats about each collection
                    collection_stats = {}
                    for collection in collections:
                        try:
                            count = mongo_db[collection].count_documents({})
                            collection_stats[collection] = {
                                'document_count': count
                            }
                        except Exception as coll_err:
                            collection_stats[collection] = {
                                'error': str(coll_err)
                            }
                    
                    mongodb_status['collection_stats'] = collection_stats
                    
                    # Get database stats
                    try:
                        db_stats = mongo_db.command("dbStats")
                        mongodb_status['db_stats'] = {
                            'collections': db_stats.get('collections'),
                            'views': db_stats.get('views'),
                            'objects': db_stats.get('objects'),
                            'storage_size': db_stats.get('storageSize'),
                            'indexes': db_stats.get('indexes'),
                            'index_size': db_stats.get('indexSize')
                        }
                    except Exception as stats_err:
                        mongodb_status['db_stats_error'] = str(stats_err)
            except Exception as e:
                mongodb_status['ping'] = {
                    'success': False,
                    'error': str(e)
                }
        
        return jsonify(mongodb_status)
    except Exception as e:
        return jsonify({
            'status': 'error',
            'message': f'Error checking database status: {str(e)}'
        })

# Helper functions for word management
def get_user_word_balance(username):
    """Get a user's word balance."""
    from datetime import datetime
    try:
        # Find the user
        user = get_user(username)
        if not user:
            # Return default balance if user not found
            return {
                "total_allocation": SUBSCRIPTION_PLANS["free"]["words"],
                "remaining_words": SUBSCRIPTION_PLANS["free"]["words"],
                "words_used": 0,
                "last_reset": datetime.now()
            }
        
        # Get or initialize word balance
        word_balance = user.get('word_balance', {
            "total_allocation": SUBSCRIPTION_PLANS["free"]["words"],
            "remaining_words": SUBSCRIPTION_PLANS["free"]["words"],
            "words_used": 0,
            "last_reset": datetime.now()
        })
        
        return word_balance
    except Exception as e:
        logging.error(f"Error getting word balance: {str(e)}")
        # Return default balance on error
        return {
            "total_allocation": SUBSCRIPTION_PLANS["free"]["words"],
            "remaining_words": SUBSCRIPTION_PLANS["free"]["words"],
            "words_used": 0,
            "last_reset": datetime.now()
        }

def update_user_word_balance(username, plan_id, keep_existing=False):
    """Update a user's word balance with a new subscription plan.
    
    Args:
        username: The username of the user to update
        plan_id: The plan ID to apply (from SUBSCRIPTION_PLANS)
        keep_existing: If True, add to existing words rather than resetting
    """
    from datetime import datetime, timedelta
    import logging
    
    try:
        # Ensure plan_id is a string
        plan_id = str(plan_id) if plan_id is not None else "free"
        
        # Log the parameters for debugging
        logging.info(f"Updating word balance for user {username}, plan: {plan_id}, keep_existing: {keep_existing}")
        
        # Find the user
        user = get_user(username)
        if not user:
            logging.warning(f"User not found: {username}")
            return False
        
        # Get current subscription plan details
        plan = SUBSCRIPTION_PLANS.get(plan_id)
        if not plan:
            logging.warning(f"Plan not found: {plan_id}")
            # Default to free plan if the specified plan isn't found
            plan_id = "free"
            plan = SUBSCRIPTION_PLANS.get("free")
            if not plan:
                logging.error("Even free plan not found in SUBSCRIPTION_PLANS")
                return False
        
        # Log plan details for debugging
        logging.info(f"Plan details: {plan}")
            
        # Get or initialize word balance
        current_balance = user.get('word_balance', {
            "total_allocation": 0,
            "remaining_words": 0,
            "words_used": 0,
            "last_reset": datetime.now(),
            "subscription_plan": "free",
            "expires_at": None
        })
        
        # Calculate word count to set - ensure numeric values using safe conversion
        try:
            remaining_words = safe_int_convert(current_balance.get("remaining_words", 0)) if keep_existing else 0
            plan_words = safe_int_convert(plan["words"])
            new_total = plan_words + (remaining_words if keep_existing else 0)
            logging.info(f"Word calculation: plan_words({plan_words}) + remaining({remaining_words if keep_existing else 0}) = {new_total}")
        except Exception as e:
            logging.error(f"Error converting word counts to integers: {e}")
            # Use default values if conversion fails
            new_total = safe_int_convert(plan["words"])
        
        # Calculate expiration date (1 month from now)
        expiration_date = datetime.now() + timedelta(days=30)
        
        # Set new values
        new_balance = {
            "total_allocation": new_total,
            "remaining_words": new_total,
            "words_used": 0,
            "last_reset": datetime.now(),
            "subscription_plan": plan_id,
            "expires_at": expiration_date,
            "per_request_limit": plan.get("per_request_limit", 300),
            "updated_at": datetime.now()
        }
        
        # Import users_collection directly
        from backend.db import users_collection
        
        # Update user record
        try:
            # Retrieve the user record once to avoid duplicate database queries
            user_record = users_collection.find_one({"username": username})
            if not user_record:
                logging.error(f"User record not found for {username} during word balance update")
                return False
                
            existing_history = user_record.get("subscription_history", [])
            
            # Convert numeric fields to strings where needed to avoid type errors
            words_count = str(plan["words"]) if isinstance(plan["words"], int) else plan["words"]
            price_value = str(plan["price"]) if isinstance(plan["price"], int) else plan["price"]
            
            # Create the history entry
            history_entry = {
                "plan": str(plan_id),  # Ensure plan_id is a string
                "purchased_at": datetime.now(),
                "expires_at": expiration_date,
                "words": words_count,
                "price": price_value
            }
            
            logging.info(f"Adding subscription history: {history_entry}")
            
            # Update the record
            result = users_collection.update_one(
                {"username": username},
                {"$set": {
                    "word_balance": new_balance,
                    "subscription_history": existing_history + [history_entry]
                }}
            )
            
            if result.modified_count > 0:
                logging.info(f"Successfully updated word balance for {username}")
            else:
                logging.warning(f"No document was modified when updating word balance for {username}")
                
        except Exception as e:
            logging.error(f"Error updating user record in MongoDB: {str(e)}")
            return False
        
        return True
    except Exception as e:
        logging.error(f"Error updating word balance: {str(e)}")
        return False

def update_user_word_usage(username, word_count):
    """Track word usage without reducing the remaining word count."""
    from datetime import datetime
    try:
        # Find the user
        user = get_user(username)
        if not user:
            return False
        
        # Get or initialize word balance
        word_balance = user.get('word_balance', {
            "total_allocation": SUBSCRIPTION_PLANS["free"]["words"],
            "remaining_words": SUBSCRIPTION_PLANS["free"]["words"],
            "words_used": 0,
            "last_reset": datetime.now()
        })
        
        # Update just the words_used counter - safely handle numeric conversions
        current_used = safe_int_convert(word_balance.get("words_used", 0))
        word_balance["words_used"] = current_used + word_count
        
        # Import users_collection directly
        from backend.db import users_collection
        
        # Update user record
        users_collection.update_one(
            {"username": username},
            {"$set": {"word_balance": word_balance}}
        )
        
        return True
    except Exception as e:
        logging.error(f"Error updating word usage: {str(e)}")
        return False

# Utility function to safely convert any value to an integer, handling comma-formatted strings
def safe_int_convert(value, default=0):
    """Convert any value to an integer, handling comma-formatted strings and other edge cases."""
    if value is None:
        return default
    try:
        if isinstance(value, str):
            # Remove commas and other non-numeric characters except the negative sign
            clean_value = value.replace(',', '')
            return int(clean_value)
        return int(value)
    except (ValueError, TypeError):
        return default

# Check user limit function needed by humanize route
def check_user_limit(username, limit_type):
    """Always return success for any limit check."""
    return True, "No limits applied"

# Helper function to get callback URL for payment notifications
def get_callback_url():
    """Build the callback URL for payment notifications"""
    # Use the explicitly configured callback URL if present
    callback_url = Config.CALLBACK_URL
    if callback_url:
        return f"{callback_url.rstrip('/')}/payment-callback"
    
    # Otherwise try to build it from the request
    if request:
        host = request.host_url.rstrip('/')
        return f"{host}/payment-callback"
    
    # Fallback
    return "https://example.com/payment-callback"

if __name__ == '__main__':
    try:
        # Run the Flask app
        port = int(os.environ.get('PORT', 6001))
        
        # Initialize payment processor thread before starting app
        payment_worker_thread = None
        if mongo_db is not None:
            from backend.payments import start_payment_processor, stop_payment_processor
            payment_worker_thread = start_payment_processor(mongo_db)
            logger.info("Payment processor background thread initialized before app start")
        
        try:
            # Run the Flask app with threaded=True for better handling of concurrent requests
            app.run(host='0.0.0.0', port=port, debug=True, threaded=True, use_reloader=False)
        except KeyboardInterrupt:
            logger.info("Received keyboard interrupt, shutting down gracefully...")
        finally:
            # Always clean up resources when the app is shutting down
            if payment_worker_thread:
                logger.info("Stopping payment processor...")
                stop_payment_processor()
                logger.info("Payment processor stopped")
    except Exception as e:
        logger.error(f"Error starting application: {str(e)}")
        
        # Try to clean up if exception occurs
        try:
            from backend.payments import stop_payment_processor
            stop_payment_processor()
            logger.info("Payment processor stopped after error")
        except:
            pass
