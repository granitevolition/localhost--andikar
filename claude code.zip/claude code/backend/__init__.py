# Backend package initialization
"""
Andikar AI Backend Services
Handles user authentication, API communication, and business logic
"""

import logging
import os

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

logger.info("Initializing backend package")

# Check if required modules are available
try:
    import flask
    import pymongo
    import wtforms
    import flask_wtf
    logger.info("All required packages are available")
except ImportError as e:
    logger.error(f"Missing required package: {str(e)}")

try:
    # Import payment services with error handling
    try:
        from backend.payments import (
            start_payment_processor, 
            stop_payment_processor,
            initiate_payment_async,
            process_payment_callback,
            get_transaction_status,
            format_phone_for_api,
            clear_transaction_status
        )
        logger.info("Payment services imported successfully")
    except ImportError as e:
        logger.warning(f"Could not import payment services: {str(e)}")
        # Define fallback function stubs to prevent errors
        def start_payment_processor(db): return None
        def stop_payment_processor(): pass
        def initiate_payment_async(db, username, amount, plan_id, callback_url): 
            return "fallback-id", "Payment processing not available", False
        def process_payment_callback(db, callback_data): return False, "Payment processing not available"
        def get_transaction_status(db, checkout_id, username=None): 
            return {"status": "error", "message": "Payment processing not available"}
        def format_phone_for_api(phone): return phone
        def clear_transaction_status(db, checkout_id): pass
        
    # Import form classes with error handling
    try:
        from backend.payments.forms import RegistrationForm, LoginForm, UseWordsForm
        logger.info("Form classes imported successfully")
    except ImportError as e:
        logger.warning(f"Could not import form classes: {str(e)}")
    
    logger.info("Backend module initialization complete")
except Exception as e:
    logger.error(f"Error during backend initialization: {str(e)}")

__version__ = '1.0.0'
