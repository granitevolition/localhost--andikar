import os
from pymongo import MongoClient
from werkzeug.security import generate_password_hash, check_password_hash
import logging
from config import Config

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Database configuration
DB_URI = os.environ.get('MONGO_URI', Config.MONGO_URI)
DB_NAME = os.environ.get('MONGO_DB_NAME', Config.MONGO_DB_NAME)
logger.info(f"Using MongoDB URI: {DB_URI}")
logger.info(f"Using database name: {DB_NAME}")

# Global collections
users_collection = None
payments_collection = None
transactions_collection = None

# MongoDB connection options
MONGO_OPTIONS = {
    'maxPoolSize': Config.MONGO_MAX_POOL_SIZE,
    'minPoolSize': Config.MONGO_MIN_POOL_SIZE,
    'maxIdleTimeMS': Config.MONGO_MAX_IDLE_TIME_MS,
    'connectTimeoutMS': Config.MONGO_CONNECT_TIMEOUT_MS,
    'serverSelectionTimeoutMS': Config.MONGO_SERVER_SELECTION_TIMEOUT_MS,
    'retryWrites': True
}

# Initialize MongoDB client
try:
    # Try to resolve the host first to check DNS
    hostname = DB_URI.split('@')[-1].split('/')[0]
    if '?' in hostname:
        hostname = hostname.split('?')[0]
    if ':' in hostname:
        hostname = hostname.split(':')[0]
    
    # Skip DNS resolution check - we'll attempt connection directly
    logger.info(f"Connecting directly to MongoDB host: {hostname}")
    
    # Enhanced connection options for better reliability
    enhanced_options = MONGO_OPTIONS.copy()
    enhanced_options['serverSelectionTimeoutMS'] = Config.MONGO_SERVER_SELECTION_TIMEOUT_MS
    enhanced_options['connectTimeoutMS'] = Config.MONGO_CONNECT_TIMEOUT_MS
    enhanced_options['socketTimeoutMS'] = Config.MONGO_SOCKET_TIMEOUT_MS
    enhanced_options['directConnection'] = False          # Let MongoDB driver handle connection
    
    # Add retry options for better resilience
    enhanced_options['retryReads'] = True
    enhanced_options['retryWrites'] = True
    enhanced_options['w'] = 'majority'                    # Ensure write acknowledgement
    enhanced_options['waitQueueTimeoutMS'] = 30000        # Wait queue timeout
    
    # First try to connect and validate the connection
    client = MongoClient(DB_URI, **enhanced_options)
    
    # Test the connection with a ping command and longer timeout
    client.admin.command('ping', serverSelectionTimeoutMS=15000)
    
    # Configure connection error handling and reconnection mechanism
    client.MIN_RECONNECT_DELAY = 5  # seconds
    client.MAX_RECONNECT_DELAY = 30  # seconds
    
    db = client[DB_NAME]
    
    # Collections
    users_collection = db['users']
    payments_collection = db['payments']
    transactions_collection = db['transactions']
    
    # Try to access the database to verify it works
    collections = list(db.list_collection_names())
    logger.info(f"Successfully connected to MongoDB database: {DB_NAME}")
    logger.info(f"Available collections: {collections}")
except Exception as e:
    logger.error(f"Error connecting to MongoDB: {str(e)}")
    logger.error(f"MongoDB URI: {DB_URI}")
    logger.error(f"MongoDB DB Name: {DB_NAME}")
    
    # Fallback to in-memory storage if MongoDB connection fails
    users_collection = {}
    payments_collection = {}
    transactions_collection = {}
    
    # Set global flag
    import config
    config.USING_IN_MEMORY = True
    logger.warning("Using in-memory storage instead of MongoDB due to connection failure")

def init_db():
    """Initialize the database with collections and demo data."""
    global users_collection, payments_collection, transactions_collection
    
    try:
        # Import dependencies
        from datetime import datetime
        from config import SUBSCRIPTION_PLANS, Config
        import config
        
        # Skip MongoDB operations if using in-memory storage
        if isinstance(users_collection, dict):
            logger.warning("Using in-memory storage instead of MongoDB")
            
            # Add demo user if using in-memory storage
            if "demo" not in users_collection:
                users_collection["demo"] = {
                    "username": "demo",
                    "password": generate_password_hash("demo"),
                    "email": "demo@example.com",
                    "phone_number": "0700000000",  # Add phone number for mobile payments
                    "ip_addresses": ["127.0.0.1"],  # Store IP addresses as array
                    "usage": {
                        "requests": 0,
                        "total_words": 0,
                        "last_request": None
                    },
                    "word_balance": {
                        "total_allocation": SUBSCRIPTION_PLANS["basic"]["words"],
                        "remaining_words": SUBSCRIPTION_PLANS["basic"]["words"],
                        "words_used": 0,
                        "last_reset": datetime.now(),
                        "subscription_plan": "basic",
                        "expires_at": datetime.now() + datetime.timedelta(days=30)
                    },
                    "created_at": datetime.now(),
                    "last_login": datetime.now()
                }
                logger.info("Added demo user to in-memory storage")
                
            # Add test user for easy login
            if "test" not in users_collection:
                users_collection["test"] = {
                    "username": "test",
                    "password": generate_password_hash("test"),
                    "email": "test@example.com",
                    "phone_number": "0700000001",
                    "ip_addresses": ["127.0.0.2"],  # Store IP addresses as array
                    "usage": {
                        "requests": 0,
                        "total_words": 0,
                        "last_request": None
                    },
                    "word_balance": {
                        "total_allocation": SUBSCRIPTION_PLANS["premium"]["words"],
                        "remaining_words": SUBSCRIPTION_PLANS["premium"]["words"],
                        "words_used": 0,
                        "last_reset": datetime.now(),
                        "subscription_plan": "premium",
                        "expires_at": datetime.now() + datetime.timedelta(days=30)
                    },
                    "created_at": datetime.now(),
                    "last_login": datetime.now()
                }
                logger.info("Added test user to in-memory storage")
                
            # Add admin user for advanced operations
            if "admin" not in users_collection:
                users_collection["admin"] = {
                    "username": "admin",
                    "password": generate_password_hash("admin123"),
                    "email": "admin@example.com",
                    "phone_number": "0700000002",
                    "ip_addresses": ["127.0.0.3"],  # Store IP addresses as array
                    "is_admin": True,
                    "usage": {
                        "requests": 0,
                        "total_words": 0,
                        "last_request": None
                    },
                    "word_balance": {
                        "total_allocation": SUBSCRIPTION_PLANS["enterprise"]["words"],
                        "remaining_words": SUBSCRIPTION_PLANS["enterprise"]["words"],
                        "words_used": 0,
                        "last_reset": datetime.now(),
                        "subscription_plan": "enterprise",
                        "expires_at": datetime.now() + datetime.timedelta(days=30)
                    },
                    "created_at": datetime.now(),
                    "last_login": datetime.now()
                }
                logger.info("Added admin user to in-memory storage")
                
            # Update global config
            config.USING_IN_MEMORY = True
            return
            
        # MongoDB implementation - create collections and indexes
        try:
            logger.info(f"Initializing database: {DB_NAME}")
            
            # Create collections if they don't exist
            collection_names = db.list_collection_names()
            
            if 'users' not in collection_names:
                # Create users collection
                db.create_collection('users')
                logger.info("Created users collection")
                
            if 'payments' not in collection_names:
                # Create payments collection
                db.create_collection('payments')
                logger.info("Created payments collection")
                
            if 'transactions' not in collection_names:
                # Create transactions collection
                db.create_collection('transactions')
                logger.info("Created transactions collection")
                
            # Create indexes on collections
            users_collection.create_index("username", unique=True)
            users_collection.create_index("ip_addresses")  # Index for IP address searches
            payments_collection.create_index([("checkout_id", 1)])
            payments_collection.create_index([("username", 1)])
            transactions_collection.create_index([("checkout_id", 1)])
            transactions_collection.create_index([("real_checkout_id", 1)])
            transactions_collection.create_index([("username", 1)])
            logger.info("Created indexes on collections")
            
            # Add demo user if it doesn't exist
            if users_collection.count_documents({"username": "demo"}) == 0:
                users_collection.insert_one({
                    "username": "demo",
                    "password": generate_password_hash("demo"),
                    "email": "demo@example.com",
                    "phone_number": "0700000000",
                    "ip_addresses": ["127.0.0.1"],  # Store IP addresses as array
                    "usage": {
                        "requests": 0,
                        "total_words": 0,
                        "last_request": None
                    },
                    "word_balance": {
                        "total_allocation": SUBSCRIPTION_PLANS["basic"]["words"],
                        "remaining_words": SUBSCRIPTION_PLANS["basic"]["words"],
                        "words_used": 0,
                        "last_reset": datetime.now(),
                        "subscription_plan": "basic",
                        "expires_at": datetime.now() + datetime.timedelta(days=30)
                    },
                    "created_at": datetime.now(),
                    "last_login": datetime.now()
                })
                logger.info("Added demo user to database")
                
            # Add test user if it doesn't exist
            if users_collection.count_documents({"username": "test"}) == 0:
                users_collection.insert_one({
                    "username": "test",
                    "password": generate_password_hash("test"),
                    "email": "test@example.com",
                    "phone_number": "0700000001",
                    "ip_addresses": ["127.0.0.2"],  # Store IP addresses as array
                    "usage": {
                        "requests": 0,
                        "total_words": 0,
                        "last_request": None
                    },
                    "word_balance": {
                        "total_allocation": SUBSCRIPTION_PLANS["premium"]["words"],
                        "remaining_words": SUBSCRIPTION_PLANS["premium"]["words"],
                        "words_used": 0,
                        "last_reset": datetime.now(),
                        "subscription_plan": "premium",
                        "expires_at": datetime.now() + datetime.timedelta(days=30)
                    },
                    "created_at": datetime.now(),
                    "last_login": datetime.now()
                })
                logger.info("Added test user to database")
                
            # Add admin user if it doesn't exist
            if users_collection.count_documents({"username": "admin"}) == 0:
                users_collection.insert_one({
                    "username": "admin",
                    "password": generate_password_hash("admin123"),
                    "email": "admin@example.com",
                    "phone_number": "0700000002",
                    "ip_addresses": ["127.0.0.3"],  # Store IP addresses as array
                    "is_admin": True,
                    "usage": {
                        "requests": 0,
                        "total_words": 0,
                        "last_request": None
                    },
                    "word_balance": {
                        "total_allocation": SUBSCRIPTION_PLANS["enterprise"]["words"],
                        "remaining_words": SUBSCRIPTION_PLANS["enterprise"]["words"],
                        "words_used": 0,
                        "last_reset": datetime.now(),
                        "subscription_plan": "enterprise",
                        "expires_at": datetime.now() + datetime.timedelta(days=30)
                    },
                    "created_at": datetime.now(),
                    "last_login": datetime.now()
                })
                logger.info("Added admin user to database")
            
            # Count total users for status report
            user_count = users_collection.count_documents({})
            logger.info(f"Database initialization completed successfully. Total users: {user_count}")
            
        except Exception as db_init_error:
            logger.error(f"Error during database initialization: {str(db_init_error)}")
            
            # If MongoDB initialization fails, fall back to in-memory storage
            users_collection = {}
            payments_collection = {}
            transactions_collection = {}
            
            # Set in-memory flag and add demo users
            config.USING_IN_MEMORY = True
            logger.warning("Falling back to in-memory storage due to database initialization error")
            
            # Retry the initialization for in-memory
            init_db()
            return
        
        logger.info("Database initialization completed")
    except Exception as e:
        logger.error(f"Error initializing database: {str(e)}")

def add_user(username, password, email, phone_number=None, ip_address=None):
    """Add a new user to the database."""
    try:
        from datetime import datetime, timedelta
        from config import SUBSCRIPTION_PLANS
        
        # Check if username already exists
        existing_user = get_user(username)
        if existing_user:
            return False, "Username already exists"
        
        # Check if too many free accounts already use this IP (for free accounts only)
        if ip_address:
            # Count free accounts with this IP
            free_accounts_with_this_ip = 0
            
            if isinstance(users_collection, dict):
                # In-memory fallback
                for u_name, u_data in users_collection.items():
                    user_ips = u_data.get('ip_addresses', [])
                    user_plan = u_data.get('word_balance', {}).get('subscription_plan', 'free')
                    if ip_address in user_ips and user_plan == 'free':
                        free_accounts_with_this_ip += 1
            else:
                # MongoDB implementation
                free_accounts_with_this_ip = users_collection.count_documents({
                    "ip_addresses": ip_address,
                    "word_balance.subscription_plan": "free"
                })
            
            # Check if we hit the limit - free accounts can only have 1 per IP
            if free_accounts_with_this_ip >= 1:
                return False, "This IP is already associated with a free account. Please use that account or subscribe to a premium plan."
        
        # Create the initial IP address list
        ip_addresses = [ip_address] if ip_address else []
        
        # Create new user
        if isinstance(users_collection, dict):
            # In-memory fallback
            users_collection[username] = {
                "username": username,
                "password": generate_password_hash(password),
                "email": email,
                "phone_number": phone_number,
                "ip_addresses": ip_addresses,  # Store IP addresses as array
                "usage": {
                    "requests": 0,
                    "total_words": 0,
                    "last_request": None
                },
                "word_balance": {
                    "total_allocation": SUBSCRIPTION_PLANS["free"]["words"],
                    "remaining_words": SUBSCRIPTION_PLANS["free"]["words"],
                    "words_used": 0,
                    "last_reset": datetime.now(),
                    "subscription_plan": "free",
                    "per_request_limit": SUBSCRIPTION_PLANS["free"]["per_request_limit"],
                    "expires_at": None  # Free accounts don't expire
                },
                "created_at": datetime.now(),
                "last_login": datetime.now()
            }
            return True, "User created successfully"
        
        # MongoDB implementation
        user_data = {
            "username": username,
            "password": generate_password_hash(password),
            "email": email,
            "phone_number": phone_number,
            "ip_addresses": ip_addresses,  # Store IP addresses as array
            "usage": {
                "requests": 0,
                "total_words": 0,
                "last_request": None
            },
            "word_balance": {
                "total_allocation": SUBSCRIPTION_PLANS["free"]["words"],
                "remaining_words": SUBSCRIPTION_PLANS["free"]["words"],
                "words_used": 0,
                "last_reset": datetime.now(),
                "subscription_plan": "free",
                "per_request_limit": SUBSCRIPTION_PLANS["free"]["per_request_limit"],
                "expires_at": None  # Free accounts don't expire
            },
            "created_at": datetime.now(),
            "last_login": datetime.now()
        }
        
        result = users_collection.insert_one(user_data)
        if result.inserted_id:
            return True, "User created successfully"
        return False, "Failed to create user"
    except Exception as e:
        logger.error(f"Error adding user: {str(e)}")
        return False, str(e)

def add_user_ip(username, ip_address):
    """Add a new IP address to a user's profile if not already present"""
    try:
        # Skip if IP is None
        if not ip_address:
            return True, "No IP address provided"
            
        user = get_user(username)
        if not user:
            return False, "User not found"
            
        # Get subscription plan to check IP limit
        subscription_plan = user.get('word_balance', {}).get('subscription_plan', 'free')
        current_plan = subscription_plan if subscription_plan else 'free'
        
        # Get IP addresses and current count
        from config import SUBSCRIPTION_PLANS
        ip_addresses = user.get('ip_addresses', [])
        ip_limit = SUBSCRIPTION_PLANS.get(current_plan, {}).get('ip_limit', 1)
        
        # Skip if this IP is already registered
        if ip_address in ip_addresses:
            return True, "IP address already registered"
            
        # Check if adding this IP would exceed the limit
        if len(ip_addresses) >= ip_limit:
            # If this user has hit their IP limit, we could either:
            # 1. Remove the oldest IP and add the new one (rotating IPs)
            # 2. Refuse to add the new IP
            # 3. Suggest upgrading their plan
            
            # For free accounts, suggest upgrading
            if current_plan == 'free':
                return False, f"You've reached the IP address limit for your {current_plan} plan. Consider upgrading to use multiple devices."
                
            # For paid accounts, rotate IPs (remove oldest, add newest)
            ip_addresses.pop(0)  # Remove oldest IP
        
        # Add the new IP
        ip_addresses.append(ip_address)
        
        # Update in storage
        if isinstance(users_collection, dict):
            # In-memory fallback
            users_collection[username]['ip_addresses'] = ip_addresses
        else:
            # MongoDB implementation
            users_collection.update_one(
                {"username": username},
                {"$set": {"ip_addresses": ip_addresses}}
            )
            
        return True, f"IP address added (total: {len(ip_addresses)})"
    except Exception as e:
        logger.error(f"Error adding IP address: {str(e)}")
        return False, str(e)

def get_user(username):
    """Get a user by username."""
    try:
        if isinstance(users_collection, dict):
            # In-memory fallback
            return users_collection.get(username)
        
        # MongoDB implementation
        user = users_collection.find_one({"username": username})
        return user
    except Exception as e:
        logger.error(f"Error getting user: {str(e)}")
        return None

def verify_user(username, password):
    """Verify a user's credentials."""
    try:
        user = get_user(username)
        if not user:
            return False, "User not found"
        
        if isinstance(users_collection, dict):
            # In-memory fallback
            if check_password_hash(user["password"], password):
                return True, user
            return False, "Invalid password"
        
        # MongoDB implementation
        if check_password_hash(user["password"], password):
            return True, user
        return False, "Invalid password"
    except Exception as e:
        logger.error(f"Error verifying user: {str(e)}")
        return False, str(e)

def update_user_usage(username, words_processed):
    """Update a user's usage statistics."""
    try:
        if isinstance(users_collection, dict):
            # In-memory fallback
            if username not in users_collection:
                return False, "User not found"
            
            user = users_collection[username]
            user["usage"]["requests"] += 1
            user["usage"]["total_words"] += words_processed
            user["usage"]["last_request"] = "now"  # Simplified for in-memory
            return True, "Usage updated"
        
        # MongoDB implementation
        from datetime import datetime
        result = users_collection.update_one(
            {"username": username},
            {"$inc": {
                "usage.requests": 1,
                "usage.total_words": words_processed
            },
            "$set": {
                "usage.last_request": datetime.now()
            }}
        )
        
        if result.modified_count:
            return True, "Usage updated"
        return False, "Failed to update usage"
    except Exception as e:
        logger.error(f"Error updating user usage: {str(e)}")
        return False, str(e)

# Payment-related database functions
def create_payment(username, amount, subscription_type, checkout_id, status='queued'):
    """Create a new payment record"""
    try:
        from datetime import datetime
        
        if isinstance(payments_collection, dict):
            # In-memory fallback
            payment_id = f"payment_{len(payments_collection) + 1}"
            payments_collection[payment_id] = {
                "username": username,
                "amount": amount,
                "subscription_type": subscription_type,
                "checkout_id": checkout_id,
                "reference": "N/A",
                "status": status,
                "timestamp": datetime.now()
            }
            return True, payment_id
        
        # MongoDB implementation
        payment = {
            "username": username,
            "amount": amount,
            "subscription_type": subscription_type,
            "checkout_id": checkout_id,
            "reference": "N/A",
            "status": status,
            "timestamp": datetime.now()
        }
        
        result = payments_collection.insert_one(payment)
        if result.inserted_id:
            return True, str(result.inserted_id)
        return False, "Failed to create payment record"
    except Exception as e:
        logger.error(f"Error creating payment: {str(e)}")
        return False, str(e)

def create_transaction(transaction_data):
    """Create a new transaction record"""
    try:
        if isinstance(transactions_collection, dict):
            # In-memory fallback
            transaction_id = f"transaction_{len(transactions_collection) + 1}"
            transactions_collection[transaction_id] = {
                **transaction_data,
                "updated_at": transaction_data.get("timestamp")
            }
            return True, transaction_id
        
        # MongoDB implementation
        result = transactions_collection.insert_one(transaction_data)
        if result.inserted_id:
            return True, str(result.inserted_id)
        return False, "Failed to create transaction record"
    except Exception as e:
        logger.error(f"Error creating transaction: {str(e)}")
        return False, str(e)

def get_user_payments(username):
    """Get all payments for a user"""
    try:
        if isinstance(payments_collection, dict):
            # In-memory fallback
            return [
                payment for payment_id, payment in payments_collection.items()
                if payment["username"] == username
            ]
        
        # MongoDB implementation
        return list(payments_collection.find({"username": username}).sort("timestamp", -1))
    except Exception as e:
        logger.error(f"Error getting user payments: {str(e)}")
        return []

def get_transaction_by_checkout_id(checkout_id):
    """Get a transaction by checkout ID"""
    try:
        if isinstance(transactions_collection, dict):
            # In-memory fallback
            for transaction_id, transaction in transactions_collection.items():
                if transaction.get("checkout_id") == checkout_id:
                    return transaction
            return None
        
        # MongoDB implementation
        transaction = transactions_collection.find_one({"checkout_id": checkout_id})
        if not transaction:
            # Try with real_checkout_id field
            transaction = transactions_collection.find_one({"real_checkout_id": checkout_id})
        
        return transaction
    except Exception as e:
        logger.error(f"Error getting transaction: {str(e)}")
        return None

def update_transaction_status(checkout_id, status, error=None):
    """Update a transaction status"""
    try:
        from datetime import datetime
        
        if isinstance(transactions_collection, dict):
            # In-memory fallback
            for transaction_id, transaction in transactions_collection.items():
                if transaction.get("checkout_id") == checkout_id:
                    transaction["status"] = status
                    transaction["updated_at"] = "now"  # Simplified for in-memory
                    if error:
                        transaction["error"] = error
                    return True
            return False
        
        # MongoDB implementation
        update_data = {
            "status": status,
            "updated_at": datetime.now()
        }
        
        if error:
            update_data["error"] = error
        
        result = transactions_collection.update_one(
            {"checkout_id": checkout_id},
            {"$set": update_data}
        )
        
        if result.modified_count:
            return True
        
        # Try with real_checkout_id
        result = transactions_collection.update_one(
            {"real_checkout_id": checkout_id},
            {"$set": update_data}
        )
        
        return result.modified_count > 0
    except Exception as e:
        logger.error(f"Error updating transaction status: {str(e)}")
        return False

def update_payment_status(checkout_id, status, reference=None):
    """Update a payment status"""
    try:
        if isinstance(payments_collection, dict):
            # In-memory fallback
            for payment_id, payment in payments_collection.items():
                if payment.get("checkout_id") == checkout_id:
                    payment["status"] = status
                    if reference:
                        payment["reference"] = reference
                    return True
            return False
        
        # MongoDB implementation
        update_data = {"status": status}
        if reference:
            update_data["reference"] = reference
        
        result = payments_collection.update_one(
            {"checkout_id": checkout_id},
            {"$set": update_data}
        )
        
        return result.modified_count > 0
    except Exception as e:
        logger.error(f"Error updating payment status: {str(e)}")
        return False