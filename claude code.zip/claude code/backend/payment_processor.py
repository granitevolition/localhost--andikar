"""
Payment processor for Andikar AI payment system.
Integrates with Lipia payment gateway.
"""

import os
import time
import uuid
import logging
import threading
import queue
from datetime import datetime
from .db import db, users_collection

# Configure logging
logger = logging.getLogger(__name__)

# Collections
payments_collection = db['payments']
transactions_collection = db['transactions']

# In-memory status tracking
payment_queue = queue.Queue()
transaction_status = {}

# Payment plans
SUBSCRIPTION_PLANS = {
    "free": {
        "words": 5000,
        "price": 0
    },
    "basic": {
        "words": 30000,
        "price": 9.99
    },
    "premium": {
        "words": 100000,
        "price": 24.99
    }
}

# Payment timeout in seconds
PAYMENT_TIMEOUT = 60

def format_phone(phone_number):
    """Format phone number for payment API."""
    # Remove any non-digit characters
    phone = ''.join(filter(str.isdigit, phone_number))
    
    # Add country code if needed
    if len(phone) == 10 and phone.startswith('0'):
        phone = '254' + phone[1:]
    elif len(phone) == 9 and not phone.startswith('0'):
        phone = '254' + phone
    
    return phone

def process_payment(username, plan_id, phone_number=None):
    """
    Process payment for a user.
    
    Args:
        username: User to process payment for
        plan_id: Subscription plan ID
        phone_number: Optional phone number for mobile payment
        
    Returns:
        tuple: (success, checkout_id or error message)
    """
    try:
        # Get plan details
        if plan_id not in SUBSCRIPTION_PLANS:
            return False, "Invalid subscription plan"
        
        plan = SUBSCRIPTION_PLANS[plan_id]
        amount = plan["price"]
        words = plan["words"]
        
        # Skip payment processing for free plan
        if amount == 0:
            # Update user's word count
            update_word_count(username, words)
            
            # Create a completed payment record
            payment_record = {
                "username": username,
                "amount": amount,
                "currency": "USD",
                "checkout_id": str(uuid.uuid4()),
                "subscription_type": plan_id,
                "status": "completed",
                "timestamp": datetime.now()
            }
            
            payments_collection.insert_one(payment_record)
            return True, payment_record["checkout_id"]
        
        # Generate a unique checkout ID
        checkout_id = str(uuid.uuid4())
        
        # Create initial payment record
        payment_record = {
            "username": username,
            "amount": amount,
            "currency": "USD",
            "checkout_id": checkout_id,
            "subscription_type": plan_id,
            "status": "pending",
            "timestamp": datetime.now()
        }
        
        # Create transaction record
        transaction_record = {
            "checkout_id": checkout_id,
            "status": "queued",
            "created_at": datetime.now(),
            "updated_at": datetime.now()
        }
        
        # Add transaction to database
        transactions_collection.insert_one(transaction_record)
        
        # Add payment to database
        payments_collection.insert_one(payment_record)
        
        # Add to in-memory status tracking
        transaction_status[checkout_id] = "queued"
        
        # Queue the payment for processing
        payment_data = {
            "checkout_id": checkout_id,
            "username": username,
            "amount": amount,
            "subscription_type": plan_id,
            "phone_number": phone_number,
            "words": words,
            "timestamp": datetime.now()
        }
        
        payment_queue.put(payment_data)
        logger.info(f"Payment queued for processing: {checkout_id}")
        
        return True, checkout_id
        
    except Exception as e:
        logger.error(f"Error processing payment: {str(e)}")
        return False, str(e)

def update_word_count(username, words):
    """
    Update a user's word count.
    
    Args:
        username: User to update
        words: Number of words to add
        
    Returns:
        boolean: Success or failure
    """
    try:
        # Find the user
        user = users_collection.find_one({"username": username})
        if not user:
            logger.error(f"User not found: {username}")
            return False
        
        # Get or initialize word balance
        word_balance = user.get('word_balance', {
            "total_allocation": 0,
            "remaining_words": 0,
            "words_used": 0,
            "last_reset": datetime.now()
        })
        
        # Calculate new values
        total_allocation = words
        remaining_words = words
        
        # Update word balance
        word_balance = {
            "total_allocation": total_allocation,
            "remaining_words": remaining_words,
            "words_used": 0,
            "last_reset": datetime.now()
        }
        
        # Update the user
        users_collection.update_one(
            {"username": username},
            {"$set": {"word_balance": word_balance}}
        )
        
        return True
    except Exception as e:
        logger.error(f"Error updating word count: {str(e)}")
        return False

def consume_words(username, word_count):
    """
    Consume words from a user's account.
    
    Args:
        username: User to consume words from
        word_count: Number of words to consume
        
    Returns:
        tuple: (success, remaining_words)
    """
    try:
        # Find the user
        user = users_collection.find_one({"username": username})
        if not user:
            logger.error(f"User not found: {username}")
            return False, 0
        
        # Get word balance
        word_balance = user.get('word_balance', {
            "total_allocation": 0,
            "remaining_words": 0,
            "words_used": 0,
            "last_reset": datetime.now()
        })
        
        # Check if user has enough words
        remaining_words = word_balance.get("remaining_words", 0)
        if remaining_words < word_count:
            logger.warning(f"Not enough words: {username} has {remaining_words}, needs {word_count}")
            return False, remaining_words
        
        # Calculate new values
        new_remaining = remaining_words - word_count
        words_used = word_balance.get("words_used", 0) + word_count
        
        # Update word balance
        word_balance["remaining_words"] = new_remaining
        word_balance["words_used"] = words_used
        
        # Update the user
        users_collection.update_one(
            {"username": username},
            {"$set": {"word_balance": word_balance}}
        )
        
        return True, new_remaining
    except Exception as e:
        logger.error(f"Error consuming words: {str(e)}")
        return False, 0

def get_payment_status(checkout_id):
    """
    Get the status of a payment.
    
    Args:
        checkout_id: Checkout ID to check
        
    Returns:
        str: Payment status or 'unknown'
    """
    try:
        # First check in-memory status
        if checkout_id in transaction_status:
            return transaction_status[checkout_id]
        
        # Then check database
        transaction = transactions_collection.find_one({"checkout_id": checkout_id})
        if transaction:
            return transaction.get("status", "unknown")
        
        return "unknown"
    except Exception as e:
        logger.error(f"Error getting payment status: {str(e)}")
        return "unknown"

def update_payment_status(checkout_id, status, error=None):
    """
    Update the status of a payment.
    
    Args:
        checkout_id: Checkout ID to update
        status: New status
        error: Optional error message
        
    Returns:
        boolean: Success or failure
    """
    try:
        # Update in-memory status
        transaction_status[checkout_id] = status
        
        # Update transaction in database
        update_data = {
            "status": status,
            "updated_at": datetime.now()
        }
        
        if error:
            update_data["error"] = error
        
        transactions_collection.update_one(
            {"checkout_id": checkout_id},
            {"$set": update_data}
        )
        
        # Update payment in database
        payments_collection.update_one(
            {"checkout_id": checkout_id},
            {"$set": {"status": status}}
        )
        
        return True
    except Exception as e:
        logger.error(f"Error updating payment status: {str(e)}")
        return False

def process_payment_callback(checkout_id, status, transaction_data=None):
    """
    Process payment callback from payment provider.
    
    Args:
        checkout_id: Checkout ID
        status: Payment status
        transaction_data: Additional transaction data
        
    Returns:
        boolean: Success or failure
    """
    try:
        # Get the payment
        payment = payments_collection.find_one({"checkout_id": checkout_id})
        if not payment:
            logger.error(f"Payment not found: {checkout_id}")
            return False
        
        username = payment["username"]
        subscription_type = payment["subscription_type"]
        
        # Update payment status
        update_payment_status(checkout_id, status)
        
        # If payment completed, update word count
        if status == "completed" and subscription_type in SUBSCRIPTION_PLANS:
            words = SUBSCRIPTION_PLANS[subscription_type]["words"]
            update_word_count(username, words)
            logger.info(f"Word count updated for user {username}: +{words} words")
        
        return True
    except Exception as e:
        logger.error(f"Error processing payment callback: {str(e)}")
        return False

def cancel_payment(checkout_id):
    """
    Cancel a pending payment.
    
    Args:
        checkout_id: Checkout ID to cancel
        
    Returns:
        boolean: Success or failure
    """
    try:
        # Get current status
        status = get_payment_status(checkout_id)
        if status not in ["queued", "pending"]:
            return False
        
        # Update status to canceled
        update_payment_status(checkout_id, "canceled")
        return True
    except Exception as e:
        logger.error(f"Error canceling payment: {str(e)}")
        return False

def _process_payment_worker():
    """Background worker to process payments from queue."""
    while True:
        try:
            # Get payment from queue with timeout
            try:
                payment_data = payment_queue.get(timeout=1)
            except queue.Empty:
                continue
            
            checkout_id = payment_data["checkout_id"]
            username = payment_data["username"]
            amount = payment_data["amount"]
            subscription_type = payment_data["subscription_type"]
            phone_number = payment_data["phone_number"]
            words = payment_data["words"]
            
            # Update status to processing
            update_payment_status(checkout_id, "processing")
            
            # For demo purposes, we'll simulate payment processing
            logger.info(f"Processing payment {checkout_id} for {username}")
            
            # Simulated processing delay
            time.sleep(2)
            
            # Simulated success
            success = True
            
            if success:
                # Update status to completed
                update_payment_status(checkout_id, "completed")
                
                # Update word count
                update_word_count(username, words)
                
                logger.info(f"Payment {checkout_id} completed successfully")
            else:
                # Update status to failed
                update_payment_status(checkout_id, "failed", "Payment processing failed")
                logger.error(f"Payment {checkout_id} failed")
            
            # Mark task as done
            payment_queue.task_done()
            
        except Exception as e:
            logger.error(f"Error in payment worker: {str(e)}")
            time.sleep(1)  # Prevent tight loop on error

# Start background worker
payment_worker = threading.Thread(target=_process_payment_worker, daemon=True)
payment_worker.start()