import os
import logging
import uuid
from datetime import datetime
from .db import db, users_collection

# Configure logging
logger = logging.getLogger(__name__)

# Initialize payments collections
payments_collection = db['payments']
plans_collection = db['plans']

# Define subscription plans
DEFAULT_PLANS = [
    {
        "plan_id": "free",
        "name": "Free Plan",
        "description": "Basic access with limited features",
        "price": 0,
        "currency": "USD",
        "interval": "month",
        "features": [
            "5,000 words per month",
            "Max 500 words per text",
            "Basic AI detection"
        ],
        "limits": {
            "max_words_per_text": 500,
            "daily_detection_limit": 5,
            "total_words": 5000
        }
    },
    {
        "plan_id": "basic",
        "name": "Basic Plan",
        "description": "Enhanced access for regular users",
        "price": 9.99,
        "currency": "USD",
        "interval": "month",
        "features": [
            "30,000 words per month",
            "Max 2,000 words per text",
            "Advanced AI detection",
            "Email support"
        ],
        "limits": {
            "max_words_per_text": 2000,
            "daily_detection_limit": 50,
            "total_words": 30000
        }
    },
    {
        "plan_id": "premium",
        "name": "Premium Plan",
        "description": "Unlimited access for power users",
        "price": 24.99,
        "currency": "USD",
        "interval": "month",
        "features": [
            "100,000 words per month",
            "Max 10,000 words per text",
            "Priority processing",
            "Advanced AI detection with detailed analysis",
            "Priority email support"
        ],
        "limits": {
            "max_words_per_text": 10000,
            "daily_detection_limit": float('inf'),
            "total_words": 100000
        }
    }
]

def init_plans():
    """Initialize subscription plans in the database."""
    try:
        # Create a plans collection if it doesn't exist
        if 'plans' not in db.list_collection_names():
            db.create_collection('plans')
        
        # Check if plans already exist
        if plans_collection.count_documents({}) == 0:
            # Insert default plans
            plans_collection.insert_many(DEFAULT_PLANS)
            logger.info("Default plans initialized in database")
        else:
            logger.info("Plans collection already initialized")
    except Exception as e:
        logger.error(f"Error initializing plans: {str(e)}")

def get_all_plans():
    """Get all available subscription plans."""
    try:
        return list(plans_collection.find({}, {'_id': 0}))
    except Exception as e:
        logger.error(f"Error retrieving plans: {str(e)}")
        return DEFAULT_PLANS  # Fallback to default plans

def get_plan(plan_id):
    """Get a specific plan by ID."""
    try:
        plan = plans_collection.find_one({"plan_id": plan_id}, {'_id': 0})
        if not plan:
            # Fallback to default plans if not found in DB
            for default_plan in DEFAULT_PLANS:
                if default_plan["plan_id"] == plan_id:
                    return default_plan
            return None
        return plan
    except Exception as e:
        logger.error(f"Error retrieving plan {plan_id}: {str(e)}")
        # Fallback to default plans
        for default_plan in DEFAULT_PLANS:
            if default_plan["plan_id"] == plan_id:
                return default_plan
        return None

def update_user_plan(username, plan_id):
    """Update a user's subscription plan."""
    try:
        plan = get_plan(plan_id)
        if not plan:
            return False, f"Plan {plan_id} does not exist"
        
        # Initialize user's word balance based on the plan
        total_words = plan["limits"].get("total_words", 0)
        
        # Update the user's plan
        result = users_collection.update_one(
            {"username": username},
            {"$set": {
                "subscription": {
                    "plan_id": plan_id,
                    "start_date": datetime.now(),
                    "status": "active",
                    "renewal_date": datetime.now().replace(day=1).replace(month=datetime.now().month + 1 if datetime.now().month < 12 else 1, year=datetime.now().year if datetime.now().month < 12 else datetime.now().year + 1)
                },
                "word_balance": {
                    "total_allocation": total_words,
                    "remaining_words": total_words,
                    "words_used": 0,
                    "last_reset": datetime.now()
                }
            }}
        )
        
        if result.modified_count:
            # Record the subscription change in payments
            payment_record = {
                "payment_id": str(uuid.uuid4()),
                "username": username,
                "plan_id": plan_id,
                "amount": plan["price"],
                "currency": plan["currency"],
                "status": "completed",
                "timestamp": datetime.now(),
                "description": f"Subscription to {plan['name']}",
                "payment_method": "test" if plan_id == "free" else "credit_card"
            }
            payments_collection.insert_one(payment_record)
            
            return True, f"Successfully subscribed to {plan['name']}"
        return False, "Failed to update subscription"
    except Exception as e:
        logger.error(f"Error updating user plan: {str(e)}")
        return False, str(e)

def get_user_plan(username):
    """Get a user's current subscription plan details."""
    try:
        user = users_collection.find_one({"username": username})
        if not user or 'subscription' not in user:
            # Default to free plan if user has no subscription
            return get_plan("free")
        
        plan_id = user['subscription'].get('plan_id', 'free')
        return get_plan(plan_id)
    except Exception as e:
        logger.error(f"Error retrieving user plan: {str(e)}")
        return get_plan("free")  # Default to free plan on error

def get_user_payment_history(username):
    """Get a user's payment history."""
    try:
        payments = list(payments_collection.find(
            {"username": username},
            {'_id': 0}
        ).sort("timestamp", -1))  # Sort by timestamp descending
        
        return payments
    except Exception as e:
        logger.error(f"Error retrieving payment history: {str(e)}")
        return []

def get_user_word_balance(username):
    """Get a user's current word balance."""
    try:
        user = users_collection.find_one({"username": username})
        if not user:
            return {
                "total_allocation": 0,
                "remaining_words": 0,
                "words_used": 0,
                "last_reset": datetime.now()
            }
        
        # Get or initialize word balance
        word_balance = user.get('word_balance', {
            "total_allocation": 0,
            "remaining_words": 0,
            "words_used": 0,
            "last_reset": datetime.now()
        })
        
        # Check if word balance needs to be reset (e.g., new billing cycle)
        if user.get('subscription', {}).get('renewal_date'):
            renewal_date = user['subscription']['renewal_date']
            if datetime.now() >= renewal_date:
                # Reset word balance for new billing cycle
                plan = get_user_plan(username)
                total_words = plan.get('limits', {}).get('total_words', 0)
                
                word_balance = {
                    "total_allocation": total_words,
                    "remaining_words": total_words,
                    "words_used": 0,
                    "last_reset": datetime.now()
                }
                
                # Update next renewal date
                next_renewal = renewal_date.replace(
                    month=renewal_date.month + 1 if renewal_date.month < 12 else 1,
                    year=renewal_date.year if renewal_date.month < 12 else renewal_date.year + 1
                )
                
                # Update user in database
                users_collection.update_one(
                    {"username": username},
                    {"$set": {
                        "word_balance": word_balance,
                        "subscription.renewal_date": next_renewal
                    }}
                )
        
        return word_balance
    except Exception as e:
        logger.error(f"Error retrieving word balance: {str(e)}")
        return {
            "total_allocation": 0,
            "remaining_words": 0,
            "words_used": 0,
            "error": str(e)
        }

def check_user_limit(username, limit_type):
    """Check if a user has reached their usage limit."""
    try:
        # Get the user's current plan
        plan = get_user_plan(username)
        if not plan:
            return False, "Invalid subscription plan"
        
        # Get the user
        user = users_collection.find_one({"username": username})
        if not user:
            return False, "User not found"
        
        # Check for word balance limit
        if limit_type == "word_balance":
            # Get user's word balance
            word_balance = user.get('word_balance', {})
            remaining_words = word_balance.get('remaining_words', 0)
            
            if remaining_words <= 0:
                return False, f"You have used all your allocated words for this billing cycle. Please upgrade your plan for more words."
            return True, f"Word balance available: {remaining_words} words"
            
        # Get the limit for the specified type
        if limit_type not in plan.get('limits', {}):
            return True, "No limit defined for this action"
        
        limit = plan['limits'][limit_type]
        
        # If limit is infinity, user has no restrictions
        if limit == float('inf'):
            return True, "No limit"
        
        # For the max_words_per_text limit, we directly compare with the limit
        if limit_type == "max_words_per_text":
            return True, f"Max words per text: {limit}"
        
        # Get the user's daily usage count
        daily_usage = user.get('daily_usage', {})
        today = datetime.now().strftime('%Y-%m-%d')
        
        # Initialize today's usage if not present
        if today not in daily_usage:
            daily_usage[today] = {
                "humanizations": 0,
                "detections": 0,
                "words_processed": 0
            }
        
        # Check the specific limit
        if limit_type == "daily_detection_limit":
            current_usage = daily_usage[today].get("detections", 0)
            if current_usage >= limit:
                return False, f"Daily limit of {limit} reached for AI detection"
            return True, f"Within limit ({current_usage}/{limit})"
        
        return True, "No applicable limit"
    except Exception as e:
        logger.error(f"Error checking user limit: {str(e)}")
        return False, str(e)

def update_user_usage(username, usage_type, count=1):
    """Update a user's daily usage statistics and word balance."""
    try:
        today = datetime.now().strftime('%Y-%m-%d')
        
        # Get the user
        user = users_collection.find_one({"username": username})
        if not user:
            return False, "User not found"
        
        # Initialize daily usage if not present
        daily_usage = user.get('daily_usage', {})
        if today not in daily_usage:
            daily_usage[today] = {
                "humanizations": 0,
                "detections": 0,
                "words_processed": 0
            }
        
        # Update the specific usage type
        if usage_type == "humanizations":
            daily_usage[today]["humanizations"] = daily_usage[today].get("humanizations", 0) + 1
        elif usage_type == "detections":
            daily_usage[today]["detections"] = daily_usage[today].get("detections", 0) + 1
        elif usage_type == "words_processed":
            daily_usage[today]["words_processed"] = daily_usage[today].get("words_processed", 0) + count
            
            # Update word balance
            word_balance = user.get('word_balance', {
                "total_allocation": 0,
                "remaining_words": 0,
                "words_used": 0,
                "last_reset": datetime.now()
            })
            
            # Calculate new word balance
            current_used = word_balance.get("words_used", 0)
            new_used = current_used + count
            total_allocation = word_balance.get("total_allocation", 0)
            new_remaining = max(0, total_allocation - new_used)
            
            # Update word balance
            word_balance["words_used"] = new_used
            word_balance["remaining_words"] = new_remaining
            
            # Update the user's word balance in the database
            users_collection.update_one(
                {"username": username},
                {"$set": {"word_balance": word_balance}}
            )
        
        # Update the user's daily usage in the database
        users_collection.update_one(
            {"username": username},
            {"$set": {"daily_usage": daily_usage}}
        )
        
        return True, "Usage updated"
    except Exception as e:
        logger.error(f"Error updating user usage: {str(e)}")
        return False, str(e)

def process_payment(username, plan_id, payment_method, card_details=None):
    """Process a subscription payment."""
    try:
        plan = get_plan(plan_id)
        if not plan:
            return False, f"Plan {plan_id} does not exist"
        
        # For a real implementation, this would integrate with a payment gateway
        # For this demo, we'll simulate a successful payment
        
        # Create payment record
        payment_id = str(uuid.uuid4())
        payment_record = {
            "payment_id": payment_id,
            "username": username,
            "plan_id": plan_id,
            "amount": plan["price"],
            "currency": plan["currency"],
            "status": "processing",
            "timestamp": datetime.now(),
            "description": f"Subscription to {plan['name']}",
            "payment_method": payment_method
        }
        
        # If a real payment gateway was used, the card details would be sent there
        # Instead, we'll just simulate the payment process
        
        # Store initial payment record
        payments_collection.insert_one(payment_record)
        
        # Simulate payment processing
        # In a real system, this would be a callback from the payment gateway
        success = True  # Simulate successful payment
        
        if success:
            # Update payment status
            payments_collection.update_one(
                {"payment_id": payment_id},
                {"$set": {"status": "completed"}}
            )
            
            # Update user's subscription
            update_user_plan(username, plan_id)
            
            return True, {
                "payment_id": payment_id,
                "status": "completed",
                "message": f"Payment successful. Subscribed to {plan['name']}."
            }
        else:
            # Update payment status to failed
            payments_collection.update_one(
                {"payment_id": payment_id},
                {"$set": {"status": "failed"}}
            )
            
            return False, {
                "payment_id": payment_id,
                "status": "failed",
                "message": "Payment processing failed."
            }
    except Exception as e:
        logger.error(f"Error processing payment: {str(e)}")
        return False, str(e)