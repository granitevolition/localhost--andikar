import os
import requests
import time
import logging
import re
import uuid
from bs4 import BeautifulSoup
from .db import update_user_usage

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# API configuration
API_URL = os.environ.get('API_URL', 'https://web-production-3db6c.up.railway.app/humanize_text')
API_KEY = os.environ.get('API_KEY', '7c8a3202ae14857e71e3a9db78cf62139772cae6')  # Use default API key from config

# Configuration parameters
DEFAULT_TIMEOUT = int(os.environ.get('API_TIMEOUT', '60'))  # Increased timeout (default: 60 seconds)
RETRY_COUNT = int(os.environ.get('API_RETRY_COUNT', '2'))   # Number of retries

class HumanizerAPIError(Exception):
    """Custom exception for API errors."""
    pass

def count_words(text):
    """Count the number of words in the given text."""
    # Split text by whitespace and count non-empty strings
    words = re.findall(r'\b\w+\b', text)
    return len(words)

def humanize_selected_text(html_content, selected_ranges, username, preserve_formatting=True, preserve_quotes=False,
                      preserve_bold=False, preserve_headings=False, preserve_links=False,
                      preserve_images=True, preserve_lists=False, custom_elements='',
                      preservation_level='medium', humanization_strength='moderate'):
    """
    Selectively humanize only the parts of the text that were selected by the user.
    
    Args:
        html_content (str): The full HTML content
        selected_ranges (list): List of selected text ranges to humanize
        username (str): The username of the user making the request
        preserve_formatting (bool): Whether to preserve paragraphs and formatting
        preserve_quotes (bool): Whether to preserve text inside quotation marks
        preserve_bold (bool): Whether to preserve bold text
        preserve_headings (bool): Whether to preserve headings
        preserve_links (bool): Whether to preserve links
        preserve_images (bool): Whether to preserve images
        preserve_lists (bool): Whether to preserve lists
        custom_elements (str): Custom CSS selectors for elements to preserve
        preservation_level (str): High, medium, or low
        humanization_strength (str): Subtle, moderate, or strong
        
    Returns:
        dict: A dictionary containing the humanized HTML content and metrics
    """
    # This is a simplified implementation - a real implementation would need to
    # parse the HTML and find the exact selected text based on the selection ranges
    
    try:
        # Parse the HTML
        soup = BeautifulSoup(html_content, 'html.parser')
        
        # Track metrics
        total_words_processed = 0
        total_selections = len(selected_ranges)
        start_time = time.time()
        
        # For each selection, extract it, humanize it, and replace it in the HTML
        for i, selection in enumerate(selected_ranges):
            # In a real implementation, this would extract the exact text using the selection range
            # For now, we'll just use the selection's text directly
            selection_text = selection.get('text', '')
            
            if not selection_text.strip():
                continue
            
            # Count words in the selection
            selection_words = count_words(selection_text)
            total_words_processed += selection_words
            
            logger.info(f"Processing selection {i+1}/{total_selections}: {selection_words} words")
            
            # Humanize this selection
            result = humanize_text(selection_text, username, 
                                preserve_formatting=preserve_formatting,
                                preserve_quotes=preserve_quotes,
                                preserve_bold=preserve_bold,
                                preserve_headings=preserve_headings,
                                preserve_links=preserve_links,
                                preserve_images=preserve_images,
                                preserve_lists=preserve_lists,
                                custom_elements=custom_elements,
                                preservation_level=preservation_level,
                                humanization_strength=humanization_strength)
            
            humanized_selection = result.get('humanized_text', selection_text)
            
            # Find the element with the class 'to-humanize' that contains this selection
            # In a real implementation, this would use the selection range data
            # For now, we'll search for the text in the HTML
            # This is a simplified approach and would need to be improved for a real implementation
            found = False
            for element in soup.find_all(class_='to-humanize'):
                if selection_text in element.get_text():
                    # Replace the content with the humanized version
                    new_element = BeautifulSoup(f'<span class="humanized-text">{humanized_selection}</span>', 'html.parser')
                    element.replace_with(new_element)
                    found = True
                    break
            
            if not found:
                logger.warning(f"Could not find selection in HTML: {selection_text[:50]}...")
        
        # Calculate response time
        response_time = time.time() - start_time
        
        # Return the updated HTML and metrics
        return {
            'humanized_text': str(soup),
            'metrics': {
                'input_words': total_words_processed,
                'output_words': count_words(str(soup)),
                'response_time': response_time,
                'selections_processed': total_selections
            }
        }
    except Exception as e:
        logger.error(f"Error selectively humanizing text: {str(e)}")
        # Return the original HTML as a fallback
        return {
            'humanized_text': html_content,
            'metrics': {
                'error': str(e),
                'selections_processed': 0
            }
        }

def humanize_text(text, username, preserve_formatting=True, preserve_quotes=False,
              preserve_bold=False, preserve_headings=False, preserve_links=False,
              preserve_images=True, preserve_lists=False, custom_elements='',
              preservation_level='medium', humanization_strength='moderate'):
    """
    Humanize the given text using the external API.
    
    Args:
        text (str): The text to humanize
        username (str): The username of the user making the request
        preserve_formatting (bool): Whether to preserve paragraphs and formatting
        preserve_quotes (bool): Whether to preserve text inside quotation marks
        preserve_bold (bool): Whether to preserve bold text
        preserve_headings (bool): Whether to preserve headings
        preserve_links (bool): Whether to preserve links
        preserve_images (bool): Whether to preserve images
        preserve_lists (bool): Whether to preserve lists
        custom_elements (str): Custom CSS selectors for elements to preserve
        preservation_level (str): High, medium, or low
        humanization_strength (str): Subtle, moderate, or strong
        
    Returns:
        dict: A dictionary containing the humanized text and metrics
        
    Raises:
        HumanizerAPIError: If there's an issue with the API request
    """
    # Record metrics
    start_time = time.time()
    
    # Store format elements with placeholders
    format_placeholders = {}
    
    # Parse the text as HTML if it contains HTML tags
    is_html = '<' in text and '>' in text
    
    # If text has HTML, extract and preserve specific elements based on settings
    if is_html and preserve_formatting:
        # This would be a more complex implementation using an HTML parser
        # For now, we'll just do basic preservation with regex
        logger.info(f"Preserving formatting with settings: Bold={preserve_bold}, Headings={preserve_headings}, Links={preserve_links}, Images={preserve_images}, Lists={preserve_lists}")
        
        # Format preservation would be handled here in a real implementation
        # This would use an HTML parser to extract and replace elements with placeholders
        # For now, we'll just use the existing implementation
        pass
        
    # If preserving quotes is enabled, extract and store them before processing
    quote_placeholders = {}
    if preserve_quotes:
        # Find all text within double quotes
        double_quotes_pattern = r'"([^"]*?)"'
        double_quotes = re.findall(double_quotes_pattern, text)
        
        # Find all text within single quotes
        single_quotes_pattern = r"'([^']*?)'" 
        single_quotes = re.findall(single_quotes_pattern, text)
        
        # Create unique placeholders for each quote and store them
        for i, quote in enumerate(double_quotes):
            placeholder = f"__QUOTE_PLACEHOLDER_DOUBLE_{i}__"
            quote_placeholders[placeholder] = f'"{quote}"'
            text = text.replace(f'"{quote}"', placeholder, 1)
            
        for i, quote in enumerate(single_quotes):
            placeholder = f"__QUOTE_PLACEHOLDER_SINGLE_{i}__"
            quote_placeholders[placeholder] = f"'{quote}'"
            text = text.replace(f"'{quote}'" , placeholder, 1)
        
        logger.info(f"Preserved {len(double_quotes)} double quotes and {len(single_quotes)} single quotes")
    
    # If preserve_formatting is enabled, split text into paragraphs and process each one
    if preserve_formatting and '\n' in text:
        paragraphs = text.split('\n\n')
        if len(paragraphs) == 1:  # If no double line breaks, try single line breaks
            paragraphs = text.split('\n')
        
        # Filter out empty paragraphs
        paragraphs = [p for p in paragraphs if p.strip()]
        
        # Count total words
        word_count = count_words(text)
        
        # Log the request
        logger.info(f"Humanizing text in {len(paragraphs)} chunks for user {username} - {word_count} words")
        
        # Process each paragraph separately
        humanized_paragraphs = []
        total_input_words = 0
        total_output_words = 0
        
        for i, para in enumerate(paragraphs):
            para_words = count_words(para)
            total_input_words += para_words
            
            # Skip empty paragraphs
            if not para.strip():
                humanized_paragraphs.append('')
                continue
                
            # Process paragraph
            logger.info(f"Processing paragraph {i+1}/{len(paragraphs)} ({para_words} words)")
            
            result = process_text_chunk(para, username, preserve_quotes=preserve_quotes,
                                       preserve_formatting=preserve_formatting,
                                       preserve_bold=preserve_bold,
                                       preserve_headings=preserve_headings,
                                       preserve_links=preserve_links,
                                       preserve_images=preserve_images,
                                       preserve_lists=preserve_lists,
                                       custom_elements=custom_elements,
                                       preservation_level=preservation_level,
                                       humanization_strength=humanization_strength)
            humanized_para = result.get('humanized_text', para)
            total_output_words += count_words(humanized_para)
            
            humanized_paragraphs.append(humanized_para)
        
        # Join paragraphs back together with double newlines
        humanized_text = '\n\n'.join(humanized_paragraphs)
        
        # Restore any preserved quotes if needed
        if preserve_quotes and quote_placeholders:
            for placeholder, original_quote in quote_placeholders.items():
                humanized_text = humanized_text.replace(placeholder, original_quote)
                logger.info(f"Restored quote: {original_quote[:30]}...")
        
        # Restore any preserved format elements if needed
        if is_html and preserve_formatting and format_placeholders:
            for placeholder, original_element in format_placeholders.items():
                humanized_text = humanized_text.replace(placeholder, original_element)
                logger.info(f"Restored format element: {original_element[:30]}...")
        
        # Calculate response time
        response_time = time.time() - start_time
        
        # Return the combined result
        return {
            'humanized_text': humanized_text,
            'metrics': {
                'input_words': word_count,
                'output_words': total_output_words,
                'response_time': response_time,
                'paragraphs_processed': len(paragraphs)
            }
        }
    else:
        # Process the entire text as a single chunk
        # Count words in the input text
        word_count = count_words(text)
        
        # Log the request
        logger.info(f"Humanizing text for user {username} - {word_count} words")
    
    # Initialize retry counter
    retry_count = 0
    
    # If text is very long (more than 1000 words), use longer timeout
    timeout = DEFAULT_TIMEOUT
    if word_count > 1000:
        timeout = DEFAULT_TIMEOUT * 2
    
    while retry_count <= RETRY_COUNT:
        try:
            # Make the API request
            payload = {"input_text": text}
            headers = {}
            
            # Import from config if available
            try:
                from config import Config
                configured_api_key = Config.API_KEY
                if configured_api_key and configured_api_key != 'default-key':
                    headers['Authorization'] = f'Bearer {configured_api_key}'
                elif API_KEY:
                    headers['Authorization'] = f'Bearer {API_KEY}'
                logger.info(f"Using API key: {'Found' if 'Authorization' in headers else 'None'}")
            except ImportError:
                # Fall back to module-level API_KEY
                if API_KEY:
                    headers['Authorization'] = f'Bearer {API_KEY}'
                logger.info(f"Using fallback API key: {'Found' if 'Authorization' in headers else 'None'}")
            
            if retry_count > 0:
                logger.info(f"Retry attempt {retry_count} for user {username}")
            
            # Send the request
            response = requests.post(API_URL, json=payload, headers=headers, timeout=timeout)
            
            # Calculate response time
            response_time = time.time() - start_time
            
            # Check for API errors
            if response.status_code != 200:
                error_msg = f"API request failed with status code {response.status_code}"
                try:
                    error_detail = response.json()
                    error_msg += f" - {error_detail}"
                except:
                    pass
                logger.error(error_msg)
                
                # If it's a server error (5xx), retry
                if response.status_code >= 500 and retry_count < RETRY_COUNT:
                    retry_count += 1
                    time.sleep(1)  # Wait before retry
                    continue
                
                raise HumanizerAPIError(error_msg)
            
            # Parse the response
            try:
                response_data = response.json()
                logger.info(f"API response: {response_data}")
                
                # Extract the humanized text from the response based on different possible formats
                humanized_text = None
                
                # Try different possible response formats
                if 'humanized_text' in response_data:
                    humanized_text = response_data['humanized_text']
                    logger.info(f"Found humanized_text in response: {humanized_text[:100]}...")
                elif 'output_text' in response_data:
                    humanized_text = response_data['output_text']
                    logger.info(f"Found output_text in response: {humanized_text[:100]}...")
                elif 'result' in response_data:
                    humanized_text = response_data['result']
                    logger.info(f"Found result in response: {humanized_text[:100]}...")
                elif 'text' in response_data:
                    humanized_text = response_data['text']
                    logger.info(f"Found text in response: {humanized_text[:100]}...")
                else:
                    # If no recognized format, use the first string value found
                    for key, value in response_data.items():
                        if isinstance(value, str) and len(value) > 10:  # Reasonable text size
                            humanized_text = value
                            logger.info(f"Using fallback key '{key}' in response: {humanized_text[:100]}...")
                            break
                
                # If we still don't have humanized text, use the whole response as a fallback
                if not humanized_text:
                    logger.warning(f"No text found in response. Using full response as fallback.")
                    humanized_text = str(response_data)
                    if len(humanized_text) < 10:
                        # If the response is too short, it's probably not valid text
                        logger.error(f"Response too short, likely invalid: {humanized_text}")
                        humanized_text = text  # Use original text as fallback
                        humanized_text += "\n\n[Note: The API returned an invalid response. Please try again later.]"
                
                # Restore any preserved quotes if needed
                if preserve_quotes and quote_placeholders:
                    for placeholder, original_quote in quote_placeholders.items():
                        humanized_text = humanized_text.replace(placeholder, original_quote)
                        logger.info(f"Restored quote: {original_quote[:30]}...")
                
                # Restore any preserved HTML elements if needed
                if is_html and preserve_formatting and format_placeholders:
                    for placeholder, original_element in format_placeholders.items():
                        humanized_text = humanized_text.replace(placeholder, original_element)
                        logger.info(f"Restored format element: {original_element[:30]}...")
                
                # Update user usage statistics
                update_user_usage(username, word_count)
                
                # Return the humanized text and metrics
                return {
                    'humanized_text': humanized_text,
                    'metrics': {
                        'input_words': word_count,
                        'output_words': count_words(humanized_text),
                        'response_time': response_time,
                        'retries': retry_count
                    }
                }
                
            except Exception as e:
                logger.error(f"Error parsing API response: {str(e)}")
                raise HumanizerAPIError(f"Error parsing API response: {str(e)}")
                
        except requests.RequestException as e:
            logger.error(f"Error making API request: {str(e)}")
            
            # Retry for network-related errors, but not if we've hit the limit
            if retry_count < RETRY_COUNT:
                retry_count += 1
                time.sleep(1)  # Wait before retry
                continue
            else:
                # If we've exhausted retries, try a local fallback
                if 'timeout' in str(e).lower():
                    # Create a simple fallback response for timeout errors
                    logger.info(f"Using fallback response for {username} after timeout")
                    response_time = time.time() - start_time
                    
                    # Simple fallback humanization (very basic)
                    fallback_text = text
                    # Add a note about using fallback
                    fallback_notice = "\n\n[Note: This text was processed using a fallback method due to API timeout. For better results, try again with shorter text or during non-peak hours.]"
                    
                    return {
                        'humanized_text': fallback_text + fallback_notice,
                        'metrics': {
                            'input_words': word_count,
                            'output_words': count_words(fallback_text),
                            'response_time': response_time,
                            'retries': retry_count,
                            'fallback': True
                        }
                    }
                
                raise HumanizerAPIError(f"Error making API request after {retry_count} retries: {str(e)}")

def extract_and_preserve_html_elements(html, preserve_bold=False, preserve_headings=False, 
                                preserve_links=False, preserve_images=True, 
                                preserve_lists=False, custom_elements=''):
    """
    Extract and preserve HTML elements based on preservation settings.
    
    Args:
        html (str): HTML content to process
        preserve_bold (bool): Whether to preserve bold text
        preserve_headings (bool): Whether to preserve headings
        preserve_links (bool): Whether to preserve links
        preserve_images (bool): Whether to preserve images
        preserve_lists (bool): Whether to preserve lists
        custom_elements (str): Custom CSS selectors for elements to preserve
        
    Returns:
        tuple: (processed_html, placeholders_dict)
    """
    if not html or not ('<' in html and '>' in html):
        return html, {}
    
    try:
        # Parse HTML with BeautifulSoup
        soup = BeautifulSoup(html, 'html.parser')
        placeholders = {}
        
        # Process images - always preserve by default
        if preserve_images:
            images = soup.find_all('img')
            for img in images:
                placeholder = f"__HTML_IMG_{uuid.uuid4()}__"
                placeholders[placeholder] = str(img)
                img.replace_with(placeholder)
        
        # Process bold text
        if preserve_bold:
            bold_tags = soup.find_all(['b', 'strong'])
            for tag in bold_tags:
                placeholder = f"__HTML_BOLD_{uuid.uuid4()}__"
                placeholders[placeholder] = str(tag)
                tag.replace_with(placeholder)
        
        # Process headings
        if preserve_headings:
            heading_tags = soup.find_all(['h1', 'h2', 'h3', 'h4', 'h5', 'h6'])
            for tag in heading_tags:
                placeholder = f"__HTML_HEADING_{uuid.uuid4()}__"
                placeholders[placeholder] = str(tag)
                tag.replace_with(placeholder)
        
        # Process links
        if preserve_links:
            link_tags = soup.find_all('a')
            for tag in link_tags:
                placeholder = f"__HTML_LINK_{uuid.uuid4()}__"
                placeholders[placeholder] = str(tag)
                tag.replace_with(placeholder)
        
        # Process lists
        if preserve_lists:
            list_tags = soup.find_all(['ul', 'ol', 'li'])
            for tag in list_tags:
                placeholder = f"__HTML_LIST_{uuid.uuid4()}__"
                placeholders[placeholder] = str(tag)
                tag.replace_with(placeholder)
        
        # Process custom elements if provided
        if custom_elements and custom_elements.strip():
            try:
                # Split by commas and process each selector
                selectors = [s.strip() for s in custom_elements.split(',')]
                for selector in selectors:
                    if not selector:
                        continue
                    custom_tags = soup.select(selector)
                    for tag in custom_tags:
                        placeholder = f"__HTML_CUSTOM_{uuid.uuid4()}__"
                        placeholders[placeholder] = str(tag)
                        tag.replace_with(placeholder)
            except Exception as e:
                logger.error(f"Error processing custom selector '{custom_elements}': {str(e)}")
        
        # Get the processed HTML
        processed_html = str(soup)
        return processed_html, placeholders
    
    except Exception as e:
        logger.error(f"Error preserving HTML elements: {str(e)}")
        return html, {}

def process_text_chunk(text, username, preserve_quotes=False, preserve_formatting=True,
                    preserve_bold=False, preserve_headings=False, preserve_links=False,
                    preserve_images=True, preserve_lists=False, custom_elements='',
                    preservation_level='medium', humanization_strength='moderate'):
    """
    Process a single chunk of text with the API.
    Helper function for humanize_text when processing in chunks.
    
    Args:
        text (str): Text chunk to process
        username (str): Username for tracking
        preserve_quotes (bool): Whether to preserve text in quotes 
    """
    # Count words in the input text
    word_count = count_words(text)
    
    # Store format elements with placeholders
    format_placeholders = {}
    
    # Parse the text as HTML if it contains HTML tags
    is_html = '<' in text and '>' in text
    
    # If text has HTML, extract and preserve specific elements based on settings
    if is_html and preserve_formatting:
        logger.info(f"Processing HTML chunk with preservation settings: Bold={preserve_bold}, Headings={preserve_headings}, Links={preserve_links}, Images={preserve_images}, Lists={preserve_lists}")
        processed_text, element_placeholders = extract_and_preserve_html_elements(
            text, preserve_bold, preserve_headings, preserve_links, preserve_images, preserve_lists, custom_elements
        )
        if element_placeholders:
            format_placeholders.update(element_placeholders)
            text = processed_text
            logger.info(f"Preserved {len(element_placeholders)} HTML elements using placeholders")
    
    # If preserving quotes is enabled, extract and store them before processing
    quote_placeholders = {}
    if preserve_quotes:
        # Find all text within double quotes
        double_quotes_pattern = r'"([^"]*?)"'
        double_quotes = re.findall(double_quotes_pattern, text)
        
        # Find all text within single quotes
        single_quotes_pattern = r"'([^']*?)'" 
        single_quotes = re.findall(single_quotes_pattern, text)
        
        # Create unique placeholders for each quote and store them
        for i, quote in enumerate(double_quotes):
            placeholder = f"__QUOTE_PLACEHOLDER_DOUBLE_{i}__"
            quote_placeholders[placeholder] = f'"{quote}"'
            text = text.replace(f'"{quote}"', placeholder, 1)
            
        for i, quote in enumerate(single_quotes):
            placeholder = f"__QUOTE_PLACEHOLDER_SINGLE_{i}__"
            quote_placeholders[placeholder] = f"'{quote}'"
            text = text.replace(f"'{quote}'" , placeholder, 1)
    
    # Initialize retry counter
    retry_count = 0
    
    # If text is very long (more than 1000 words), use longer timeout
    timeout = DEFAULT_TIMEOUT
    if word_count > 1000:
        timeout = DEFAULT_TIMEOUT * 2
    
    while retry_count <= RETRY_COUNT:
        try:
            # Make the API request
            payload = {"input_text": text}
            headers = {}
            
            # Import from config if available
            try:
                from config import Config
                configured_api_key = Config.API_KEY
                if configured_api_key and configured_api_key != 'default-key':
                    headers['Authorization'] = f'Bearer {configured_api_key}'
                elif API_KEY:
                    headers['Authorization'] = f'Bearer {API_KEY}'
                logger.info(f"Using API key for chunk: {'Found' if 'Authorization' in headers else 'None'}")
            except ImportError:
                # Fall back to module-level API_KEY
                if API_KEY:
                    headers['Authorization'] = f'Bearer {API_KEY}'
                logger.info(f"Using fallback API key for chunk: {'Found' if 'Authorization' in headers else 'None'}")
            
            if retry_count > 0:
                logger.info(f"Retry attempt {retry_count} for chunk")
            
            # Send the request
            response = requests.post(API_URL, json=payload, headers=headers, timeout=timeout)
            
            # Check for API errors
            if response.status_code != 200:
                error_msg = f"API request failed with status code {response.status_code}"
                try:
                    error_detail = response.json()
                    error_msg += f" - {error_detail}"
                except:
                    pass
                logger.error(error_msg)
                
                # If it's a server error (5xx), retry
                if response.status_code >= 500 and retry_count < RETRY_COUNT:
                    retry_count += 1
                    time.sleep(1)  # Wait before retry
                    continue
                
                raise HumanizerAPIError(error_msg)
            
            # Parse the response
            try:
                response_data = response.json()
                logger.info(f"Paragraph API response: {response_data}")
                
                # Extract the humanized text from the response based on different possible formats
                humanized_text = None
                
                # Try different possible response formats
                if 'humanized_text' in response_data:
                    humanized_text = response_data['humanized_text']
                    logger.info(f"Found humanized_text in paragraph response: {humanized_text[:50]}...")
                elif 'output_text' in response_data:
                    humanized_text = response_data['output_text']
                    logger.info(f"Found output_text in paragraph response: {humanized_text[:50]}...")
                elif 'result' in response_data:
                    humanized_text = response_data['result']
                    logger.info(f"Found result in paragraph response: {humanized_text[:50]}...")
                elif 'text' in response_data:
                    humanized_text = response_data['text']
                    logger.info(f"Found text in paragraph response: {humanized_text[:50]}...")
                else:
                    # If no recognized format, use the first string value found
                    for key, value in response_data.items():
                        if isinstance(value, str) and len(value) > 10:  # Reasonable text size
                            humanized_text = value
                            logger.info(f"Using fallback key '{key}' in paragraph response: {humanized_text[:50]}...")
                            break
                
                # If we still don't have humanized text, use the original paragraph as a fallback
                if not humanized_text:
                    logger.warning(f"No text found in paragraph response. Using original paragraph as fallback.")
                    humanized_text = text
                
                # Restore any preserved quotes if needed
                if preserve_quotes and quote_placeholders:
                    for placeholder, original_quote in quote_placeholders.items():
                        humanized_text = humanized_text.replace(placeholder, original_quote)
                
                # Restore any preserved HTML elements if needed
                if is_html and preserve_formatting and format_placeholders:
                    for placeholder, original_element in format_placeholders.items():
                        humanized_text = humanized_text.replace(placeholder, original_element)
                
                # Return the humanized text
                return {
                    'humanized_text': humanized_text
                }
                
            except Exception as e:
                logger.error(f"Error parsing API response for chunk: {str(e)}")
                raise HumanizerAPIError(f"Error parsing API response: {str(e)}")
                
        except requests.RequestException as e:
            logger.error(f"Error making API request for chunk: {str(e)}")
            
            # Retry for network-related errors, but not if we've hit the limit
            if retry_count < RETRY_COUNT:
                retry_count += 1
                time.sleep(1)  # Wait before retry
                continue
            else:
                # If we've exhausted retries, return the original text
                logger.info(f"Using original text for chunk after API failure")
                
                # Restore any preserved quotes if needed
                original_text = text
                if preserve_quotes and quote_placeholders:
                    for placeholder, original_quote in quote_placeholders.items():
                        original_text = original_text.replace(placeholder, original_quote)
                
                # Restore any preserved HTML elements if needed
                if is_html and preserve_formatting and format_placeholders:
                    for placeholder, original_element in format_placeholders.items():
                        original_text = original_text.replace(placeholder, original_element)
                        
                return {
                    'humanized_text': original_text
                }

def get_api_status():
    """Check if the API is online and responding."""
    try:
        # Use a small sample text to avoid unnecessary processing
        payload = {"input_text": "Hello world."}
        headers = {}
        
        # Try to get API key from Config
        api_key_used = False
        try:
            from config import Config
            configured_api_key = Config.API_KEY
            if configured_api_key and configured_api_key != 'default-key':
                headers['Authorization'] = f'Bearer {configured_api_key}'
                api_key_used = True
            elif API_KEY:
                headers['Authorization'] = f'Bearer {API_KEY}'
                api_key_used = True
        except ImportError:
            # Fall back to module-level API_KEY
            if API_KEY:
                headers['Authorization'] = f'Bearer {API_KEY}'
                api_key_used = True
        
        logger.info(f"Checking API status with key: {'Found' if api_key_used else 'None'}")
            
        # Send a test request with increased timeout for reliability
        response = requests.post(API_URL, json=payload, headers=headers, timeout=10)
        
        # Check if the API is responding properly
        if response.status_code == 200:
            # Check for valid response structure
            try:
                response_json = response.json()
                if 'result' in response_json or 'humanized_text' in response_json or 'output_text' in response_json:
                    # API returned expected data structure
                    return {
                        'status': 'online',
                        'message': 'API is operational',
                        'url': API_URL,
                        'has_key': api_key_used,
                        'timeout': DEFAULT_TIMEOUT
                    }
                else:
                    # API returned success but unexpected data structure
                    return {
                        'status': 'warning',
                        'message': 'API is responding but may have unexpected data format',
                        'url': API_URL,
                        'has_key': api_key_used,
                        'timeout': DEFAULT_TIMEOUT
                    }
            except Exception as e:
                # Failed to parse JSON response
                return {
                    'status': 'warning',
                    'message': f'API responded but with invalid JSON: {str(e)}',
                    'url': API_URL,
                    'has_key': api_key_used,
                    'timeout': DEFAULT_TIMEOUT
                }
        else:
            return {
                'status': 'error',
                'message': f'API returned status code {response.status_code}',
                'url': API_URL,
                'has_key': api_key_used,
                'timeout': DEFAULT_TIMEOUT
            }
            
    except requests.RequestException as e:
        return {
            'status': 'offline',
            'message': f'API connection error: {str(e)}',
            'url': API_URL,
            'has_key': 'unknown',
            'timeout': DEFAULT_TIMEOUT
        }
