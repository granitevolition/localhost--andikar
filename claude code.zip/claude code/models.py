# Simulated database
users_db = {}
transactions_db = []
