# Andikar AI Text Humanizer

An AI-powered service for humanizing text content.

## MongoDB Connection Fix

If you're experiencing MongoDB connection issues like the ones shown in the logs:

```
ERROR:pymongo.client:MongoClient background task encountered an error:
OSError: connection closed
```

Follow these steps to resolve the issue:

### Option 1: Use Local MongoDB (Recommended for Development)

1. Configure a local MongoDB server:
   - Run the setup script: `python setup_local_mongodb.py`
   - Follow the instructions to install and start MongoDB locally

2. The application has been configured to use `mongodb://localhost:27017` as the default connection string.

3. Start your application and it should connect to the local MongoDB instance without issues.

### Option 2: Fix Remote MongoDB Connection

If you prefer to keep using the remote MongoDB connection:

1. Check your internet connection and network settings
   - Make sure your firewall allows MongoDB connections
   - Verify DNS resolution is working properly

2. Update the MongoDB URI in `config.py` with the correct credentials and connection string
   - Make sure the MongoDB Atlas cluster is accessible from your network
   - Check if your IP is whitelisted in MongoDB Atlas security settings

3. Increase connection timeouts:
   - The application now uses longer timeouts for MongoDB connections
   - This helps with intermittent network issues or high-latency connections

## Running the Application

1. Install required dependencies:
   ```
   pip install -r requirements.txt
   ```

2. Start the Flask application:
   ```
   python app.py
   ```

3. Access the application at http://127.0.0.1:6001

## Troubleshooting

If you continue to experience MongoDB connection issues:

1. Check the application logs for specific error messages
2. Verify MongoDB server is running correctly
3. Try restarting both the MongoDB server and the application
4. Consider using the in-memory fallback mode for development/testing

For more help, refer to the MongoDB documentation: https://docs.mongodb.com/manual/
